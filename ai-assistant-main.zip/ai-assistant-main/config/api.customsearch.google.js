
const config = {
  endpoint: "https://customsearch.googleapis.com/customsearch/v1",

  // Get Google API key at https://developers.google.com/custom-search/v1/introduction
  key: "AIzaSyAza4hoBc18nbBK6rOoPP3-xDtSNkaVbx0",

  // Get search engine ID (cx param) at https://programmablesearchengine.google.com/controlpanel/all
  cx: "96dea7513936b48e7",
};

module.exports = config;