const fs = require('fs');
const path = require('path');
require('dotenv').config();
const baseUrl = process.env.BASE_URL || "http://localhost:3000/";

const config = {
  baseUrl: baseUrl,
  projects: {
    education: {
      enabled: false,
      pages: [
        { name: "home", type: "home" },
        { name: "apply", type: "apply" },
      ],
    },
    steam: {
      enabled: true,
      pages: [
        { name: "home", type: "home", redirectTo: "education/home" },
        { name: "apply", type: "apply", redirectTo: "education/apply" },
        { name: "chat", type: "chat" },
      ],
    },
    religion: {
      enabled: false,
      pages: [
        { name: "home", type: "home" },
        { name: "apply", type: "apply" },
      ],
    },
    christianity: {
      enabled: true,
      pages: [
        { name: "home", type: "home", redirectTo: "religion/home" },
        { name: "apply", type: "apply", redirectTo: "religion/apply" },
        { name: "chat", type: "chat" },
      ],
    },
    "opm-social": {
      enabled: true,
      pages: [
        { name: "home", type: "home" },
        { name: "apply", type: "apply" },
        { name: "chat", type: "chat" },
      ],
    },
  },
  mysql: {
    host: process.env.MYSQL_HOST || "localhost",
    port: process.env.MYSQL_PORT || 3306,
    user: process.env.MYSQL_USER || "root",
    password: process.env.MYSQL_PASSWORD || "",
    database: process.env.MYSQL_DATABASE || "ai-assistant",
  },
};

for (let projectId in config.projects) {
  let projectConfig = require('../config/projects/' + projectId);
  let jsonFilename = path.resolve(__dirname, '..') + '/config/projects/' + projectId + '.json';
  let jsonConfig = fs.existsSync(jsonFilename) && fs.readFileSync(jsonFilename, "utf8");
  if (jsonConfig && (jsonConfig = JSON.parse(jsonConfig))) {
    if (jsonConfig.chatInstructions) projectConfig.chatInstructions = jsonConfig.chatInstructions;
  }
  config.projects[projectId] = { ...config.projects[projectId], ...projectConfig };
}

module.exports = config;