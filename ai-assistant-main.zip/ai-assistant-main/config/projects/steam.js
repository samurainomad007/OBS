require('dotenv').config();
const baseUrl = process.env.BASE_URL || "http://localhost:3000/";

const config = {
  id: "steam",
  name: "Steam",
  header: {
    label: "STEAM",
    title: "AI Teaching Assistant by OpenBlockSpace powered by ChatGPT",
  },
  footer: {
    content: "OpenBlockSpace adaptation of ChatGPT Feb 13 Version for K12 schools, teachers, parents & kids, with focus on STEAM (+English). Our project empowers schools and encourages parents and teachers to lead in improving children's learning using Al, just as people overcame their fears of electricity and used it to their advantage when it first started arriving to the U.S.",
  },
  start: {
    examples: [
      { title: "Art", content: "VTA, Please, help us to create a quest on modern artists biographies", },
      { title: "Math", content: "What the best approach to solve this problem: x*y*z = 1001", },
      { title: "Science", content: "Let’s discuss one of the recent scientific breakthroughs, which we can test with our school's facilities", },
    ],
    capabilities: [
      { content: "Remembers what user said earlier in the conversation", },
      { content: "Allows user to provide follow-up corrections", },
      { content: "Return conversation into the area and focus of the subject a student has signed up for", },
    ],
    limitations: [
      { content: "May occasionally generate incorrect information", },
      { content: "The teacher is responsible for managing the learning process and guiding students. Project work is focused on STEAM areas.", },
    ]
  },
  chatInstructions: "You are a school teacher assistant for the subject of {{category.title}}. You should ensure that the dialogue stays within the bounds of the subject matter. Teacher's name is {{category.teacherName}}. Your conversational partner's name is {{user.name}}. Address your conversational partner by their name in the first answer of dialogue. Use a cheerful tone and add some emojis. When asked for images or other graphic material, display them in the format ![Caption and author](URL).",
  categories: [
    { id: "science", title: "Science", teacherName: "Emma", },
    { id: "technology", title: "Technology", teacherName: "William", },
    { id: "engineering", title: "Engineering", teacherName: "James", },
    { id: "art", title: "Art", teacherName: "Mark", },
    { id: "math", title: "Math", teacherName: "Amelia", },
  ],
  profile: {
    propertyGroups: [
      { name: "basic", title: "Basic info", column: 1, },
      { name: "avatar", title: "Headshot", column: 0, },
      { name: "account", title: "Account", column: 1, },
    ],
    properties: [
      { name: "firstName", title: "First Name", type: "string", required: true, minLength: 1, maxLength: 200, inherited: true, propertyGroup: "basic", },
      { name: "lastName", title: "Last Name", type: "string", required: true, minLength: 1, maxLength: 200, inherited: true, propertyGroup: "basic", },
      { name: "organization", title: "Organization", type: "string", required: false, minLength: 0, maxLength: 200, inherited: true, propertyGroup: "basic", },
      { name: "username", title: "Email", type: "email", disabled: true, enablable: true, required: true, minLength: 0, maxLength: 200, inherited: true, propertyGroup: "account", },
      { name: "password", title: "Password", type: "password", disabled: true, enablable: true, required: true, minLength: 4, maxLength: 200, inherited: true, propertyGroup: "account", },
      //{ name: "avatarFileName", title: "Avatar", type: "text", required: false, inherited: true, propertyGroup: "avatar", },
      { name: "avatarId", title: "Avatar", type: "number", required: false, inherited: true, propertyGroup: "avatar", },
    ],
  },
};

module.exports = config;