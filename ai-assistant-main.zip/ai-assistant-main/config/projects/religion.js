require('dotenv').config();
const baseUrl = process.env.BASE_URL || "http://localhost:3000/";

const config = {
  id: "religion",
  name: "Religion",
};

module.exports = config;