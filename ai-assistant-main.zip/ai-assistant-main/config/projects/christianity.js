require('dotenv').config();
const baseUrl = process.env.BASE_URL || "http://localhost:3000/";

const config = {
  id: "christianity",
  name: "Christianity",
  header: {
    label: "CHRISTIANITY",
    title: "AI Teaching Assistant by OpenBlockSpace powered by ChatGPT",
  },
  footer: {
    content: "OpenBlockSpace adaptation of ChatGPT to focus on Christianity. Our project empowers religious organizations, improving understanding and knowledge of religion using Al, just as people have utilized new technologies throughout history to enhance their spiritual growth and connection to God.",
  },
  start: {
    examples: [
      { title: "Sacred Texts", content: "How do the Ten Commandments apply to modern-day issues?", },
      { title: "Beliefs", content: "What is the significance of the Nicene Creed in the Catholic Church?", },
      { title: "Christian Life", content: "Help people understand the Catholic concept of subsidiarity and apply it in their communities", },
    ],
    capabilities: [
      { content: "Remembers what user said earlier in the conversation", },
      { content: "Allows user to provide follow-up corrections", },
      { content: "Return conversation into the area and focus of the subject a person has signed up for", },
    ],
    limitations: [
      { content: "May occasionally generate incorrect information", },
      { content: "Project work is focused on Religion areas", },
    ]
  },
  chatInstructions: "You are an teacher's assistant at a Christian school for the subject of \"{{category.title}}\". You should ensure that the dialogue stays within the bounds of the subject matter and Christian teachings. Teacher's name is {{category.teacherName}}.\nYour conversational partner's name is {{user.name}}. Address your conversational partner by their name at the beginning of the dialogue.\nUse a cheerful tone and add some emojis.\nWhen asked for images or other graphic material, display them in the format ![Caption and author](URL).",
  categories: [
    { id: "sacredTexts", title: "Sacred Texts", teacherName: "Emma", },
    { id: "beliefs", title: "Beliefs", teacherName: "William", },
    { id: "church", title: "Church", teacherName: "James", },
    { id: "christianLife", title: "Christian Life", teacherName: "Mark", },
  ],
  profile: {
    propertyGroups: [
      { name: "basic", title: "Basic info", column: 1, },
      { name: "avatar", title: "Headshot", column: 0, },
      { name: "account", title: "Account", column: 1, },
    ],
    properties: [
      { name: "firstName", title: "First Name", type: "string", required: true, minLength: 1, maxLength: 200, inherited: true, propertyGroup: "basic", },
      { name: "lastName", title: "Last Name", type: "string", required: true, minLength: 1, maxLength: 200, inherited: true, propertyGroup: "basic", },
      { name: "organization", title: "Organization", type: "string", required: false, minLength: 0, maxLength: 200, inherited: true, propertyGroup: "basic", },
      { name: "username", title: "Email", type: "email", disabled: true, enablable: true, required: true, minLength: 0, maxLength: 200, inherited: true, propertyGroup: "account", },
      { name: "password", title: "Password", type: "password", disabled: true, enablable: true, required: true, minLength: 4, maxLength: 200, inherited: true, propertyGroup: "account", },
      //{ name: "avatarFileName", title: "Avatar", type: "text", required: false, inherited: true, propertyGroup: "avatar", },
      { name: "avatarId", title: "Avatar", type: "number", required: false, inherited: true, propertyGroup: "avatar", },
    ],
  },
};

module.exports = config;