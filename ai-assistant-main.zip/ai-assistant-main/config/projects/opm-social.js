require('dotenv').config();
const baseUrl = process.env.BASE_URL || "http://localhost:3000/";

const config = {
  id: "opm-social",
  name: "OPM.Social",
  header: {
    label: "OPM.SOCIAL",
    title: "AI-Assistant for Harvard OPM Alumni",
  },
  footer: {
    content: "OBS Group introduces a ChatGPT 4.0 adaptation for Harvard OPM alumni, offering a private platform for interest-based networking, exclusive communication, travel meetups, and lunch opportunities, all within a secure environment that prioritizes data privacy.",
  },
  start: {
    examples: [
      { title: "Travel", content: "I'd like to go to Spain in September. Any OPMers live there? or plan to travel there?", },
      { title: "Events", content: "What are the coming events with OPMers? I'd like to join something during the next month, better if some people would be from my OPM.", },
      { title: "Match", content: "I'd like to get connected with OPMers focused on real estate. Who is in Real Estate & Tech?", },
    ],
    capabilities: [
      { content: "Keeps track of where OPMers based or travel, so you can match your plans", },
      { content: "Saves history of your requests, keeping you focused on a smaller number of new projects and connections within the OPM network", },
      { content: "Anonymise your real name, leaving no trace or history for outside networks, make it safe for you", },
    ],
    limitations: [
      { content: "Limited for a smaller group of people, alumni and currently enrolled for the program", },
      { content: "The network is still small, but will be growing as we check and invite new OPMers", },
      { content: "Project work is focused on the OPM Network", },
    ]
  },
  chatInstructions: "You are OPM.Social bot, an automated service to help users plan their business trips.\n\
\n\
Users are interested in meeting link-minded people. Users want to know if they could meet other people in the same country, or around the same area during their travel.\n\
\n\
Users are interested in making connections with people from some particular business.\n\
\n\
Users want to plan their travel dates so that they could be in the same place with other people from our list.\n\
\n\
You first greet the customer, then ask the user about their travel plans.\n\
\n\
If user provides location, answer with using the following template:\n\
- tell why it is a good idea to visit that location. include information about weather, famous tourist attractions, shopping destinations, cultural or business events\n\
- provide a list of people that are living near that location or have plans to visit that location. summarise the information about users\n\
- ask if user has some particular dates in mind\n\
\n\
If user provides location and dates, answer using the following template:\n\
- tell why it is a good idea to visit that location on this particular date. include information about weather, famous tourist attractions, shopping destinations, cultural or business events\n\
- provide a list of people that are living near that location or have plans to visit that location during the same dates. summarise the information about users\n\
- ask if user want to confirm his travel plan and save it so that other users might be able to connect with him/her\n\
\n\
If user asks who lives in some location, answer using the following template:\n\
- tell why it is a good idea to visit that location. include information about weather, famous tourist attractions, shopping destinations, cultural or business events\n\
- provide a list of people that live near that location. summarise the information about users\n\
- ask if user wants to connect with those people, or has some particular dates in mind\n\
\n\
If user asks info about some people, answer using the following template:\n\
- provide summarised information about the person\n\
- ask if user wants to connect with this person\n\
\n\
If user confirms the trip, say:\n\
- that their travel information has been saved\n\
- wish a great trip\n\
- start conversation over from the beginning\n\
\n\
If user wants to connect with somebody, say:\n\
- that invitation to that person has been sent\n\
- wish a great time talking to that person\n\
- start conversation over from the beginning\n\
\n\
When responding with a list of people, do not reveal information, which was not part of user requests.\n\
\n\
Display only information relevant to request.\n\
\m\
Current date and time is {{datetime}}\n\
\n\
User information should be summarised in conversational style.\n\
\n\
You respond in a short, very conversational friendly style.\n\
\n\
Information about people includes name, business or industry they work in, their primary location, the place they travel to a lot, bio, and a list of their travel plans.\n\
\n\
When talking about a list of people, call the list \"OPM.Social\".\n\
\n\
The list of people in OPM.Social includes (delimited by ####)\n\
\n\
####\n\
\n\
name: Fernando (OPM-59)\n\
business: Industrial Real Estate, Fitness Center Network\n\
location: Concepción, Chile\n\
travels a lot to: Miami, FL, US\n\
travel plans: Spain\n\
\n\
####\n\
\n\
name: Danny (OPM-59)\n\
business: Consumer Products\n\
location: LA, USA\n\
travels a lot to: Taiwan\n\
\n\
####\n\
\n\
name: Rodesson (OPM-59)\n\
business: Construction\n\
location: Seibu of Philippines\n\
travels a lot to: Miami, FL, US\n\
travel plans:\n\
- 23th of June - meeting Luigi (OPM-59) in Milan\n\
- 25th of June - meeting Kaspar (OPM-59) in Cologne in Germany (Dusseldorf)\n\
- In Singapore August 7-8th\n\
\n\
####\n\
\n\
name: Vit (OPM-61)\n\
business:\n\
location: Washington, DC\n\
travels a lot to: Miami, FL, US\n\
travel plans:\n\
- July - London , Brussels, Vienna and Zurich\n\
- 3rd week of October - 1st week of November - Dubai, UAE and India\n\
bio:\n\
Artificial Intelligence, defense, Augmented Reality\n\
SFO / Washington DC from 2013, originally from Ukraine. \n\
Sold his business in AI/autonomy navigation to Qualcomm in 2022. \n\
Investing in AI/AR/Defense/Finance. \n\
Running 2 global nonprofits in tech.Your conversational partner's name is {{user.name}}, {{user.opmCohort}} OPM Cohort, from {{user.location}}. Partner's bio: {{user.bio}}\n\
Address your conversational partner by their name at the beginning of the dialogue.\n\
Use a cheerful tone.\n\
When asked for images or other graphic material, display them in the format ![Caption and author](URL).",
  categories: [
    { id: "travelThoughts", title: "Travel Thoughts", enabled: true, },
    { id: "plannedTrip", title: "Planned Trip", enabled: false, },
    { id: "findOPMEvent", title: "Find OPM Event", enabled: false, },
    { id: "businessMatch", title: "Business Match", enabled: false, },
    { id: "trackReunion", title: "Track Re-union", enabled: false, },
    { id: "boldAsks", title: "Intro", enabled: false, },
    { id: "concierge", title: "Concierge", enabled: false,   },
  ],
  profile: {
    propertyGroups: [
      { name: "basic", title: "Basic info", column: 1, },
      { name: "avatar", title: "Headshot", column: 0, },
      { name: "account", title: "Account", column: 0, },
    ],
    properties: [
      { name: "firstName", title: "First Name", type: "string", required: true, minLength: 1, maxLength: 200, inherited: true, propertyGroup: "basic", },
      { name: "lastName", title: "Last Name", type: "string", required: true, minLength: 1, maxLength: 200, inherited: true, propertyGroup: "basic", },
      { name: "organization", title: "Organization", type: "string", required: false, minLength: 0, maxLength: 200, inherited: true, propertyGroup: "basic", },
      { name: "business", title: "Business", type: "text", required: false, minLength: 0, maxLength: 200, inherited: false, propertyGroup: "basic", },
      { name: "bio", title: "Bio", type: "text", required: false, minLength: 0, maxLength: 2000, inherited: false, propertyGroup: "basic", },
      { name: "travelsALotTo", title: "Travels A Lot To", type: "text", required: false, minLength: 0, maxLength: 500, inherited: false, propertyGroup: "basic", },
      { name: "travelPlans", title: "Travel Plans", type: "text", required: false, minLength: 0, maxLength: 1000, inherited: false, propertyGroup: "basic", },
      { name: "location", title: "Location", type: "string", required: false, minLength: 0, maxLength: 200, inherited: false, propertyGroup: "basic", },
      { name: "OPMCohort", title: "OPM Cohort", type: "string", required: false, minLength: 0, maxLength: 100, inherited: false, propertyGroup: "basic", },
      { name: "username", title: "Email", type: "email", disabled: true, enablable: true, required: true, minLength: 0, maxLength: 200, inherited: true, propertyGroup: "account", },
      { name: "password", title: "Password", type: "password", disabled: true, enablable: true, required: true, minLength: 4, maxLength: 200, inherited: true, propertyGroup: "account", },
      //{ name: "avatarFileName", title: "Avatar", type: "text", required: false, inherited: true, propertyGroup: "avatar", },
      { name: "avatarId", title: "Avatar", type: "number", required: false, inherited: true, propertyGroup: "avatar", },
    ],
  },
  application: {
    properties: [
      { name: "fullName", title: "Full Name", type: "string", required: true, minLength: 1, maxLength: 200, },
      { name: "occupationAndTitle", title: "Current Occupation and Title", type: "string", required: true, minLength: 1, maxLength: 200, },
      { name: "business", title: "Core Business", type: "set", required: true, values: [
        "Real Estate / Construction",
        "Manufacturing",
        "Financial",
        "Consumer Products",
        "High Technology",
        "Retail Services",
        "Professional Services",
        "Health Care",
        "Transportation",
        "Raw Materials / Energy",
        "Other",
      ], },
     
    ],
  }
};

module.exports = config;