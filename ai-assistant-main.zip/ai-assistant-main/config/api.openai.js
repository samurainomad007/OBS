
const config = {
  completions: {
    endpoint: "https://api.openai.com/v1/completions",
    model: "text-davinci-003",
    maxTokens: 2048,
    temperature: 0.3,
  },
  chatCompletions: {
    endpoint: "https://api.openai.com/v1/chat/completions",
    model: "gpt-4",//3.5-turbo
    maxTokens: 3000,
    temperature: 0.3,
  },
  // Get OpenAI API key at https://platform.openai.com/account/api-keys
  key: "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",
};

module.exports = config;