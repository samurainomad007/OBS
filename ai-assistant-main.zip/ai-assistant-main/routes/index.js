require('dotenv').config();
const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const config = require('../config/app');

router.get('/', async function(req, res) {
  let user;
  if (req.user?.enabled) { 
    user =  {  ...req.user, ...(req.user.data || {}) };
    delete user.data;
    user.name = user.firstName;
    user.fullName = user.firstName + (user.lastName? " " + user.lastName: "");
    if (user.avatarFileName) user.avatarUrl = config.baseUrl + "images/" + user.avatarFileName;
    else user.avatarUrl = config.baseUrl + "images/user.png";
    if (typeof user.avatarId !== "undefined") {
      let thumbnail = await res.locals.images.getResized(user.avatarId, "thumbnail");
      user.avatarUrl = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
    }
  }
  res.render('index', {
    user: user
  });
});

router.get('/login', (req, res, next) => {
  if (! req.query.guestUrl && req.query.url && ["steam", "christianity", "opm-social"].includes(req.query.url.replace(/^\//, ""))) req.query.guestUrl = req.query.url + '/home';
  res.render('login', {
    url: req.query.url  ,
    guestUrl: req.query.guestUrl,
  })
});

router.post('/login', function(req, res, next) { 
  res.locals.passport.authenticate('local', function(err, user, info) {
    if (err) { return next(err); }
    if (req.body.url && req.body.url.match(/^(https?:\/\/|\/login)/)) req.body.url = "";

    if (! user || ! user.enabled) {
      res.locals.messages = [{ message: "Access denied.", type: "error" }];
      if (! req.body.guestUrl && ["steam", "christianity", "opm-social"].includes(req.body.url.replace(/^\//, ""))) req.body.guestUrl = req.body.url + '/home';
      return res.render('login', {
        url: req.body.url,
        guestUrl: req.body.guestUrl,
        username: req.body.username,
      });
    }

    req.login(user, function (err) {
      if (err) { return next(err); }
      return res.redirect(req.body.url || "/" + (user.data.defaultProject || user.data.projects?.find(p => p.enabled && p.opened)?.id || ''));
    });
  })(req, res, next);
});

router.get('/logout', (req, res, next) => {
  req.logout(function (err) {
    if (err) { return next(err); }
    req.session.destroy(function (err) {
      res.clearCookie('OSID');
      req.user = null;
      if (req.query.url && req.query.url.match(/^(https?:\/\/|\/logout)/)) req.query.url = "";
      return res.redirect(req.query.url || "/");
    });
  });
});


router.get('/register', (req, res, next) => {
  res.render('register', {
    url: req.query.url,
    firstName: "",
    lastName: "",
    username: "",
    organization: "",
  });
});

router.post('/register', (req, res, next) => {
  let messages = res.locals.messages = [];
  if (! req.body.firstName || req.body.firstName.length < 1) messages.push({ message: "Please enter your first name.", type: "error", for: "firstName" });
  else if (req.body.firstName.length > 200) messages.push({ message: "The first name length must be less than 200 characters.", type: "error", for: "firstName" });
  if (! req.body.lastName || req.body.lastName.length < 1) messages.push({ message: "Please enter your last name.", type: "error", for: "lastName" });
  else if (req.body.lastName.length > 200) messages.push({ message: "The last name length must be less than 200 characters.", type: "error", for: "lastName" });
  if (! req.body.username || req.body.username.length < 1) messages.push({ message: "Please enter your email.", type: "error", for: "username" });
  else if (req.body.username.length > 200) messages.push({ message: "The email length must be less than 200 characters.", type: "error", for: "username" });
  else if (! req.body.username.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) messages.push({ message: "The email must be your real email address.", type: "error", for: "username" });
  if (! req.body.password || req.body.password.length < 1) messages.push({ message: "Please enter your password.", type: "error", for: "password" });
  else if (req.body.password.length < 4) messages.push({ message: "The password length must be more than 4 characters.", type: "error", for: "password" });
  else if (req.body.password.length > 200) messages.push({ message: "The password length must be less than 200 characters.", type: "error", for: "password" });
  if (messages.length) {
    messages.push({ message: (messages.length < 2? "An error": messages.length + " errors") + " have been detected in the form.", type: "error", for: "" });
    return res.render('register', {
      url: req.query.url || req.body.url,
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      username: req.body.username,
      organization: req.body.organization || "",
    });
  }
  res.locals.db.query('SELECT * FROM users WHERE username=? ', [req.body.username])
  .then(async ([rows, fields]) => {
    if (rows.length > 0) {
      res.locals.messages = [{ message: "User already exists.", type: "error", for: "username" }];
      return res.render('register', {
        url: req.query.url || req.body.url,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        username: req.body.username,
        organization: req.body.organization || "",
      });
    }
    else {
      const pass = res.locals.auth.hashPassword(req.body.password);
      const data = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        organization: req.body.organization || "",
      }

      let [results, fields] = await res.locals.db.query('INSERT INTO users(username, hash, salt, enabled, data) VALUES(?,?,?,?,?)',
        [req.body.username, pass.hash, pass.salt, 0, JSON.stringify(data)]);
      
      if (results) {
        req.session.messages.push({ message: "User registered. Please log in.", type: "success" });
        return res.redirect('/login?url=' + encodeURI(req.body.url || "/"));
      }  
    }
  })
  .catch(error => {
    console.log(error);
    return next(error);
  });
});

router.get('/partnerships/q', (req, res) => {
  return res.redirect('https://airtable.com/apptB2hDDGGEpLpAZ/shrYrpt14omCXxBN4');
});

router.get('/opm-social/nyc/27', (req, res) => {
  return res.redirect('https://airtable.com/app6K2OQpoZ9MvDAf/shrCvz9E9INMjIh91');
});

router.get('/apply', (req, res) => {
  return res.redirect('/opm-social/apply');
});

router.get('/opm-social/apply', async (req, res, next) => {
  let user;
  if (req.user?.enabled) { 
    user =  {  ...req.user, ...(req.user.data || {}) };
    delete user.data;
    user.name = user.firstName;
    user.fullName = user.firstName + (user.lastName? " " + user.lastName: "");
    if (user.avatarFileName) user.avatarUrl = config.baseUrl + "images/" + user.avatarFileName;
    else user.avatarUrl = config.baseUrl + "images/user.png";
    if (typeof user.avatarId !== "undefined") {
      let thumbnail = await res.locals.images.getResized(user.avatarId, "thumbnail");
      user.avatarUrl = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
    }
  }
  res.render('projects/opm-social/apply', {
    url: req.query.url,
    user: user,
    fullName: user?.fullName || "",
    occupationAndTitle: "",
    business: [],
    otherBusiness: "",
    businessIsBig: void 0,
    location: "",
    hangoutSpots: "",
    clubMemberships: "",
    OPMAlumnus: void 0,
    email: "",
    phone: "",
    alumnusName: "",
    alumnusEmail: "",
    travelPlans: "",
    //whyYouWishToJoin: "",
    //howDidYouHear: "",
    comments: "",
  });
});

router.post('/opm-social/apply', async (req, res, next) => {
  let user;
  if (req.user?.enabled) { 
    user =  {  ...req.user, ...(req.user.data || {}) };
    delete user.data;
    user.name = user.firstName;
    user.fullName = user.firstName + (user.lastName? " " + user.lastName: "");
    if (user.avatarFileName) user.avatarUrl = config.baseUrl + "images/" + user.avatarFileName;
    else user.avatarUrl = config.baseUrl + "images/user.png";
    if (typeof user.avatarId !== "undefined") {
      let thumbnail = await res.locals.images.getResized(user.avatarId, "thumbnail");
      user.avatarUrl = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
    }
  }
  let messages = res.locals.messages = [];
  if (! req.body.fullName || req.body.fullName.length < 1) messages.push({ message: "Please enter your name.", type: "error", for: "fullName" });
  else if (req.body.fullName.length > 200) messages.push({ message: "The name length must be less than 200 characters.", type: "error", for: "fullName" });
  if (! req.body.occupationAndTitle || req.body.occupationAndTitle.length < 1) messages.push({ message: "Please enter your current occupation and title.", type: "error", for: "occupationAndTitle" });
  else if (req.body.occupationAndTitle.length > 200) messages.push({ message: "The current occupation and title length must be less than 200 characters.", type: "error", for: "occupationAndTitle" });
  if (! req.body.business || req.body.business.length < 1) messages.push({ message: "Please select your core business.", type: "error", for: "business" });
  else {
    let business = [];
    let values = config.projects["opm-social"].application.properties.find(p => p.name === "business").values;
    req.body.business.forEach((val, i) => {
      if (values.includes(val)) business.push(val);
      else if (val && values.includes("Other")) business.push("Other");
    });
    req.body.business = business;
  }
  if (req.body.business.includes("Other")) {
    if (! req.body.otherBusiness || req.body.otherBusiness.length < 1) messages.push({ message: "Please enter your other business.", type: "error", for: "otherBusiness" });
    else if (req.body.otherBusiness.length > 200) messages.push({ message: "Other business length must be less than 200 characters.", type: "error", for: "otherBusiness" });
  }
  if (! req.body.location || req.body.location.length < 1) messages.push({ message: "Please enter your core location.", type: "error", for: "location" });
  else if (req.body.location.length > 200) messages.push({ message: "Core location length must be less than 200 characters.", type: "error", for: "location" });
  if (! req.body.hangoutSpots || req.body.hangoutSpots.length < 1) messages.push({ message: "Please provide an answer regarding hangout spots.", type: "error", for: "hangoutSpots" });
  else if (req.body.hangoutSpots.length > 1000) messages.push({ message: "The answer regarding hangout spots must be fewer than 1000 characters in length.", type: "error", for: "hangoutSpots" });
  if (! req.body.clubMemberships || req.body.clubMemberships.length < 1) messages.push({ message: "Please provide an answer regarding club memberships & guest invitations.", type: "error", for: "clubMemberships" });
  else if (req.body.clubMemberships.length > 1000) messages.push({ message: "The answer regarding club memberships & guest invitations must be fewer than 1000 characters in length.", type: "error", for: "clubMemberships" });
  if (! req.body.OPMAlumnus || req.body.OPMAlumnus.length < 1) messages.push({ message: "Please provide an answer regarding your alumni status.", type: "error", for: "OPMAlumnus" });
  else if (req.body.OPMAlumnus !== '1' && req.body.OPMAlumnus !== '0') messages.push({ message: "Incorrect answer to the question about alumni status.", type: "error", for: "OPMAlumnus" });
  if (req.body.OPMAlumnus !== '1') {
    if (! req.body.businessIsBig || req.body.businessIsBig.length < 1) messages.push({ message: "Please provide an answer regarding the scale of your business.", type: "error", for: "businessIsBig" });
    else if (req.body.businessIsBig !== '1' && req.body.businessIsBig !== '0') messages.push({ message: "Incorrect answer to the question about the scale of your business.", type: "error", for: "businessIsBig" });
  }
  if (! req.body.email || req.body.email.length < 1) messages.push({ message: "Please enter your HBS email address.", type: "error", for: "email" });
  else if (req.body.email.length > 200) messages.push({ message: "The HBS email address length must be less than 200 characters.", type: "error", for: "email" });
  else if (! req.body.email.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) messages.push({ message: "The HBS email must be a valid email address.", type: "error", for: "email" });
  if (! req.body.phone || req.body.phone.length < 1) messages.push({ message: "Please enter your phone number.", type: "error", for: "phone" });
  else if (req.body.phone.length > 200) messages.push({ message: "The HBS email length must be less than 200 characters.", type: "error", for: "phone" });
  else if (! req.body.phone.match(/^(?:(\+))?(?:[0-9]{0,3}[\s.\/-]?)?(?:(?:\((?=\d{3}\)))?(\d{3})(?:(?!\(\d{3})\))?[\s.\/-]?)?(?:(?:\((?=\d{3}\)))?(\d{3})(?:(?!\(\d{3})\))?[\s.\/-]?)?(?:(?:\((?=\d{4}\)))?(\d{4})(?:(?!\(\d{4})\))?[\s.\/-]?)?$/)) messages.push({ message: "The phone number must be in a valid international format.", type: "error", for: "phone" });
  if (! req.body.alumnusName || req.body.alumnusName.length < 1) messages.push({ message: "Please enter the name of an OPM alumnus.", type: "error", for: "alumnusName" });
  else if (req.body.alumnusName.length > 200) messages.push({ message: "The name of an OPM alumnus length must be less than 200 characters.", type: "error", for: "alumnusName" });
  if (! req.body.alumnusEmail || req.body.alumnusEmail.length < 1) messages.push({ message: "Please enter the HBS email address of an OPM alumnus.", type: "error", for: "alumnusEmail" });
  else if (req.body.alumnusEmail.length > 200) messages.push({ message: "The HBS email address length must be less than 200 characters.", type: "error", for: "alumnusEmail" });
  else if (! req.body.alumnusEmail.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) messages.push({ message: "The HBS email of an OPM alumnus must be a valid email address.", type: "error", for: "alumnusEmail" });
  if (! req.body.travelPlans || req.body.travelPlans.length < 1) messages.push({ message: "Please provide an answer regarding you travel plans.", type: "error", for: "travelPlans" });
  else if (req.body.travelPlans.length > 1000) messages.push({ message: "The answer regarding you travel plans must be fewer than 1000 characters in length.", type: "error", for: "travelPlans" });
  //if (! req.body.whyYouWishToJoin || req.body.whyYouWishToJoin.length < 1) messages.push({ message: "Please provide an answer regarding why you wish to join.", type: "error", for: "whyYouWishToJoin" });
  //else if (req.body.whyYouWishToJoin.length > 1000) messages.push({ message: "The answer regarding why you wish to join must be fewer than 1000 characters in length.", type: "error", for: "whyYouWishToJoin" });
  //if (! req.body.howDidYouHear || req.body.howDidYouHear.length < 1) messages.push({ message: "Please provide an answer regarding how you heard about us.", type: "error", for: "howDidYouHear" });
  //else if (req.body.howDidYouHear.length > 1000) messages.push({ message: "The answer regarding how you heard about us must be fewer than 1000 characters in length.", type: "error", for: "howDidYouHear" });
  if (req.body.comments && req.body.comments.length > 1000) messages.push({ message: "The comments length must be less than 1000 characters.", type: "error", for: "comments" });
  if (messages.length) {
    messages.push({ message: (messages.length < 2? "An error": messages.length + " errors") + " have been detected in the form.", type: "error", for: "" });
    return res.render('projects/opm-social/apply', {
      url: req.query.url || req.body.url,
      user: user,
      fullName: req.body.fullName || "",
      occupationAndTitle: req.body.occupationAndTitle || "",
      business: req.body.business || [],
      otherBusiness: req.body.otherBusiness || "",
      businessIsBig: req.body.businessIsBig || void 0,
      location: req.body.location || "",
      hangoutSpots: req.body.hangoutSpots || "",
      clubMemberships: req.body.clubMemberships || "",
      OPMAlumnus: req.body.OPMAlumnus || void 0,
      email: req.body.email || "",
      phone: req.body.phone || "",
      alumnusName: req.body.alumnusName || "",
      alumnusEmail: req.body.alumnusEmail || "",
      travelPlans: req.body.travelPlans || "",
      //whyYouWishToJoin: req.body.whyYouWishToJoin || "",
      //howDidYouHear: req.body.howDidYouHear || "",
      comments: req.body.comments || "",
    });
  }
  const data = [
    user?.id || 0,
    3,
    JSON.stringify({
      fullName: req.body.fullName || "",
      occupationAndTitle: req.body.occupationAndTitle || "",
      business: req.body.business || [],
      otherBusiness: req.body.otherBusiness || "",
      businessIsBig: req.body.businessIsBig || void 0,
      location: req.body.location || "",
      hangoutSpots: req.body.hangoutSpots || "",
      clubMemberships: req.body.clubMemberships || "",
      OPMAlumnus: req.body.OPMAlumnus || void 0,
      email: req.body.email || "",
      phone: req.body.phone || "",
      alumnusName: req.body.alumnusName || "",
      alumnusEmail: req.body.alumnusEmail || "",
      travelPlans: req.body.travelPlans || "",
      //whyYouWishToJoin: req.body.whyYouWishToJoin || "",
      //howDidYouHear: req.body.howDidYouHear || "",
      comments: req.body.comments || "",
    }),
  ];
  res.locals.db.query('INSERT INTO applications(user_id, project_id, data) VALUES(?,?,?)', data)
  .then(async ([results, fields]) => {
    if (results) {
      req.session.messages.push({ message: "Your application has been submitted.", type: "success" });
      return res.redirect('/login?url=' + encodeURI(req.body.url || "/opm-social"));
    }
  })
  .catch(error => {
    console.log(error);
    return next(error);
  });
});

router.get('/steam/apply', async (req, res, next) => {
  let user;
  if (req.user?.enabled) { 
    user =  {  ...req.user, ...(req.user.data || {}) };
    delete user.data;
    user.name = user.firstName;
    user.fullName = user.firstName + (user.lastName? " " + user.lastName: "");
    if (user.avatarFileName) user.avatarUrl = config.baseUrl + "images/" + user.avatarFileName;
    else user.avatarUrl = config.baseUrl + "images/user.png";
    if (typeof user.avatarId !== "undefined") {
      let thumbnail = await res.locals.images.getResized(user.avatarId, "thumbnail");
      user.avatarUrl = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
    }
  }
  res.render('projects/steam/apply', {
    url: req.query.url,
    user: user,
    fullName: user?.fullName || "",
    occupationAndTitle: "",
    email: "",
    phone: "",
  });
});

router.post('/steam/apply', async (req, res, next) => {
  let user;
  if (req.user?.enabled) { 
    user =  {  ...req.user, ...(req.user.data || {}) };
    delete user.data;
    user.name = user.firstName;
    user.fullName = user.firstName + (user.lastName? " " + user.lastName: "");
    if (user.avatarFileName) user.avatarUrl = config.baseUrl + "images/" + user.avatarFileName;
    else user.avatarUrl = config.baseUrl + "images/user.png";
    if (typeof user.avatarId !== "undefined") {
      let thumbnail = await res.locals.images.getResized(user.avatarId, "thumbnail");
      user.avatarUrl = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
    }
  }
  let messages = res.locals.messages = [];
  if (! req.body.fullName || req.body.fullName.length < 1) messages.push({ message: "Please enter your name.", type: "error", for: "fullName" });
  else if (req.body.fullName.length > 200) messages.push({ message: "The name length must be less than 200 characters.", type: "error", for: "fullName" });
  if (! req.body.occupationAndTitle || req.body.occupationAndTitle.length < 1) messages.push({ message: "Please enter your current occupation and title.", type: "error", for: "occupationAndTitle" });
  else if (req.body.occupationAndTitle.length > 200) messages.push({ message: "The current occupation and title length must be less than 200 characters.", type: "error", for: "occupationAndTitle" });
  if (! req.body.email || req.body.email.length < 1) messages.push({ message: "Please enter your email address.", type: "error", for: "email" });
  else if (req.body.email.length > 200) messages.push({ message: "The email address length must be less than 200 characters.", type: "error", for: "email" });
  else if (! req.body.email.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) messages.push({ message: "The email must be a valid email address.", type: "error", for: "email" });
  if (! req.body.phone || req.body.phone.length < 1) messages.push({ message: "Please enter your phone number.", type: "error", for: "phone" });
  else if (req.body.phone.length > 200) messages.push({ message: "The HBS email length must be less than 200 characters.", type: "error", for: "phone" });
  else if (! req.body.phone.match(/^(?:(\+))?(?:[0-9]{0,3}[\s.\/-]?)?(?:(?:\((?=\d{3}\)))?(\d{3})(?:(?!\(\d{3})\))?[\s.\/-]?)?(?:(?:\((?=\d{3}\)))?(\d{3})(?:(?!\(\d{3})\))?[\s.\/-]?)?(?:(?:\((?=\d{4}\)))?(\d{4})(?:(?!\(\d{4})\))?[\s.\/-]?)?$/)) messages.push({ message: "The phone number must be in a valid international format.", type: "error", for: "phone" });
  if (messages.length) {
    messages.push({ message: (messages.length < 2? "An error": messages.length + " errors") + " have been detected in the form.", type: "error", for: "" });
    return res.render('projects/steam/apply', {
      url: req.query.url || req.body.url,
      user: user,
      fullName: req.body.fullName || "",
      occupationAndTitle: req.body.occupationAndTitle || "",
      email: req.body.email || "",
      phone: req.body.phone || "",
    });
  }
  const data = [
    user?.id || 0,
    1,
    JSON.stringify({
      fullName: req.body.fullName || "",
      occupationAndTitle: req.body.occupationAndTitle || "",
      email: req.body.email || "",
      phone: req.body.phone || "",
    }),
  ];
  res.locals.db.query('INSERT INTO applications(user_id, project_id, data) VALUES(?,?,?)', data)
  .then(async ([results, fields]) => {
    if (results) {
      req.session.messages.push({ message: "Your application has been submitted.", type: "success" });
      return res.redirect('/login?url=' + encodeURI(req.body.url || "/steam"));
    }
  })
  .catch(error => {
    console.log(error);
    return next(error);
  });
});

router.get('/christianity/apply', async (req, res, next) => {
  let user;
  if (req.user?.enabled) { 
    user =  {  ...req.user, ...(req.user.data || {}) };
    delete user.data;
    user.name = user.firstName;
    user.fullName = user.firstName + (user.lastName? " " + user.lastName: "");
    if (user.avatarFileName) user.avatarUrl = config.baseUrl + "images/" + user.avatarFileName;
    else user.avatarUrl = config.baseUrl + "images/user.png";
    if (typeof user.avatarId !== "undefined") {
      let thumbnail = await res.locals.images.getResized(user.avatarId, "thumbnail");
      user.avatarUrl = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
    }
  }
  res.render('projects/christianity/apply', {
    url: req.query.url,
    user: user,
    fullName: user?.fullName || "",
    occupationAndTitle: "",
    email: "",
    phone: "",
  });
});

router.post('/christianity/apply', async (req, res, next) => {
  let user;
  if (req.user?.enabled) { 
    user =  {  ...req.user, ...(req.user.data || {}) };
    delete user.data;
    user.name = user.firstName;
    user.fullName = user.firstName + (user.lastName? " " + user.lastName: "");
    if (user.avatarFileName) user.avatarUrl = config.baseUrl + "images/" + user.avatarFileName;
    else user.avatarUrl = config.baseUrl + "images/user.png";
    if (typeof user.avatarId !== "undefined") {
      let thumbnail = await res.locals.images.getResized(user.avatarId, "thumbnail");
      user.avatarUrl = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
    }
  }
  let messages = res.locals.messages = [];
  if (! req.body.fullName || req.body.fullName.length < 1) messages.push({ message: "Please enter your name.", type: "error", for: "fullName" });
  else if (req.body.fullName.length > 200) messages.push({ message: "The name length must be less than 200 characters.", type: "error", for: "fullName" });
  if (! req.body.occupationAndTitle || req.body.occupationAndTitle.length < 1) messages.push({ message: "Please enter your current occupation and title.", type: "error", for: "occupationAndTitle" });
  else if (req.body.occupationAndTitle.length > 200) messages.push({ message: "The current occupation and title length must be less than 200 characters.", type: "error", for: "occupationAndTitle" });
  if (! req.body.email || req.body.email.length < 1) messages.push({ message: "Please enter your email address.", type: "error", for: "email" });
  else if (req.body.email.length > 200) messages.push({ message: "The email address length must be less than 200 characters.", type: "error", for: "email" });
  else if (! req.body.email.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) messages.push({ message: "The email must be a valid email address.", type: "error", for: "email" });
  if (! req.body.phone || req.body.phone.length < 1) messages.push({ message: "Please enter your phone number.", type: "error", for: "phone" });
  else if (req.body.phone.length > 200) messages.push({ message: "The HBS email length must be less than 200 characters.", type: "error", for: "phone" });
  else if (! req.body.phone.match(/^(?:(\+))?(?:[0-9]{0,3}[\s.\/-]?)?(?:(?:\((?=\d{3}\)))?(\d{3})(?:(?!\(\d{3})\))?[\s.\/-]?)?(?:(?:\((?=\d{3}\)))?(\d{3})(?:(?!\(\d{3})\))?[\s.\/-]?)?(?:(?:\((?=\d{4}\)))?(\d{4})(?:(?!\(\d{4})\))?[\s.\/-]?)?$/)) messages.push({ message: "The phone number must be in a valid international format.", type: "error", for: "phone" });
  if (messages.length) {
    messages.push({ message: (messages.length < 2? "An error": messages.length + " errors") + " have been detected in the form.", type: "error", for: "" });
    return res.render('projects/christianity/apply', {
      url: req.query.url || req.body.url,
      user: user,
      fullName: req.body.fullName || "",
      occupationAndTitle: req.body.occupationAndTitle || "",
      email: req.body.email || "",
      phone: req.body.phone || "",
    });
  }
  const data = [
    user?.id || 0,
    2,
    JSON.stringify({
      fullName: req.body.fullName || "",
      occupationAndTitle: req.body.occupationAndTitle || "",
      email: req.body.email || "",
      phone: req.body.phone || "",
    }),
  ];
  res.locals.db.query('INSERT INTO applications(user_id, project_id, data) VALUES(?,?,?)', data)
  .then(async ([results, fields]) => {
    if (results) {
      req.session.messages.push({ message: "Your application has been submitted.", type: "success" });
      return res.redirect('/login?url=' + encodeURI(req.body.url || "/christianity"));
    }
  })
  .catch(error => {
    console.log(error);
    return next(error);
  });
});



/*
router.get('/profile', (req, res, next) => {
  res.render('profile', {
    user: req.user,
  });
});
*/




for (let projectId in config.projects) {
  if (config.projects[projectId]?.enabled) {

    /*config.projects[projectId].pages?.forEach (page => {
      router.get('/' + projectId + (page.type === "chat"? "": "/" + page.name), (req, res, next) => {
        let projectConfig = config.projects[projectId];

        let pageRender = async next => {
          let user = {  ...(req.user || {}), ...(req.user?.data || {}), ...(req.user?.data?.projects?.find(p => p.id === projectId)?.data || {}) };
          delete user.data;

          if (! user.enabled && page.type === "chat") res.redirect('/' + projectId + '/home');          
          else {
            user.name = user.firstName;
            user.fullName = user.firstName + (user.lastName? " " + user.lastName: "");
            if (user.avatarFileName) user.avatarUrl = config.baseUrl + "images/" + user.avatarFileName;
            else user.avatarUrl = config.baseUrl + "images/user.png";
            if (typeof user.avatarId !== "undefined") {
              let thumbnail = await res.locals.images.getResized(user.avatarId, "thumbnail");
              user.avatarUrl = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
            }
          
            res.render('projects/' + projectId + '/' + (page.template || page.name), {
              project: projectConfig,
              user: user,
            });
          }
        };
        
        if (! req.user && page.type === "chat") res.locals.auth.isEnabled(req, res, pageRender);
        else pageRender();
      });
    });*/

    router.get('/' + projectId, (req, res, next) => {
      let projectConfig = config.projects[projectId];

      const render = async next => {
        let user = {  ...(req.user || {}), ...(req.user.data || {}), ...(req.user.data?.projects?.find(p => p.id === projectId)?.data || {}) };
        delete user.data;

        user.name = user.firstName;
        user.fullName = user.firstName + (user.lastName? " " + user.lastName: "");
        if (user.avatarFileName) user.avatarUrl = config.baseUrl + "images/" + user.avatarFileName;
        else user.avatarUrl = config.baseUrl + "images/user.png";
        if (typeof user.avatarId !== "undefined") {
          let thumbnail = await res.locals.images.getResized(user.avatarId, "thumbnail");
          user.avatarUrl = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
        }

        res.render('projects/' + projectId + '/index', {
          project: projectConfig,
          user: user,
        });
      };

      req.query.url = '/' + projectId;
      req.query.guestUrl = '/' + projectId + '/home';
      if (! req.user) res.locals.auth.isEnabled(req, res, render);
      else if (req.user.data.projects?.find(p => p.id === projectId && p.enabled)) render();
      else res.redirect('/');
    });

    router.get('/' + projectId + "/home", (req, res, next) => {
      let projectConfig = config.projects[projectId];
      res.render('projects/' + projectId + '/home', {
        project: projectConfig,
        //user: user,
      });
    });

    router.post('/' + projectId + "/update-config", function(req, res) {
      let jsonFilename = path.resolve(__dirname, '..') + '/config/projects/' + projectId + '.json';
      fs.writeFile(jsonFilename, JSON.stringify(req.body, void 0, 2), err => {
        if (err) { 
          res.status(500).json({ error: 'Saving error.' });
          return; 
        }
        res.json({ result: "Success." });
      });
    });
  }
}

module.exports = router;
