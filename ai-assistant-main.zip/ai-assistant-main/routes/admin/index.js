var express = require('express');
var router = express.Router();
const path = require('path');
const crypto = require('crypto');

const config = require('../../config/app');

const adminAccess = function (req, res, next) {
  if (! req.user || ! req.user.enabled || req.user.data.role !== "admin") return res.redirect('/login?url=' + encodeURI(req.originalUrl));
  return next();
}

router.get('/', adminAccess, function(req, res, next) {
  res.render('admin/index', {
    user: req.user,
  });
});

router.get('/users/', adminAccess, function(req, res, next) {
  res.locals.db.query('SELECT * FROM users WHERE 1', [])
  .then( ([rows, fields]) => {
    let users = [];
    rows.forEach(row => {
      users.push(row);
    });
    res.render('admin/users', {
      user: req.user,
      users: users,
    });
  })
  .catch(error => {
    return next(error);
  });
});

router.get('/users/:id/edit', adminAccess, async function(req, res, next) {
  try {
    let users = [];
    let images = [];
    let [rows] = await res.locals.db.query('SELECT * FROM users WHERE id=?', [req.params.id]);
    if (rows && rows.length) {
      rows.forEach(row => {
        row.data = JSON.parse(row.data);
        if (row.data.avatarId) images.push(row.data.avatarId);
        if (row.data.organization?.match(/(location:|bio:)/)) {
          row.data.notes = (row.data.notes || "") + "\n" + row.data.organization;
          row.data.organization = "";
        }
        users.push(row);
      });
    }
    if (images.length) [rows] = await res.locals.db.query("SELECT * FROM images WHERE id IN (?)", [images]);
    else rows = null;
    images = [];
    if (rows && rows.length) {
      for (let i = 0; i < rows.length; i++) {
        let img = { ...rows[i] };
        let thumbnail = await res.locals.images.getResized(img.id, "thumbnail");
        img.url = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
        images.push(img);
      }
    }
    res.render('admin/users-edit', {
      user: req.user,
      users: users,
      images: images,
    });
  }
  catch (error) {
    return next(error);
  }
});

router.post('/users/:id/edit', adminAccess, async function(req, res, next) {
  try {
    let existsUsers = [];
    let images = [];
    let [rows] = await res.locals.db.query('SELECT * FROM users WHERE id=?', [req.params.id]);
    rows.forEach(row => {
      row.data = JSON.parse(row.data);
      existsUsers.push(row);
      if (row.data.avatarId) images.push(row.data.avatarId);
    });
    
    let users = [];
    req.body.users?.forEach(async user => {
      let set = {};
      set.username = user.username?.trim() || "";
      set.enabled = +(user.enabled || 0);
      let pass;
      if (user.password) {
        pass = res.locals.auth.hashPassword(user.password);
        set.hash = pass.hash;
        set.salt = pass.salt;
      }
      set.data = {};
      set.data.firstName = user.data?.firstName?.trim() || "";
      set.data.lastName = user.data?.lastName?.trim() || "";
      //set.data.avatarFileName = user.data?.avatarFileName?.trim() || "";
      set.data.avatarId = user.data?.avatarId?.trim() || "";
      if (set.data.avatarId) {
        set.data.avatarId = +set.data.avatarId;
        images.push(set.data.avatarId);
      }
      else delete set.data.avatarId;
      set.data.organization = user.data?.organization?.trim() || "";
      set.data.notes = user.data?.notes?.trim() || "";
      set.data.defaultProject = user.data?.defaultProject?.trim() || "";
      set.data.projects = [];
      user.data?.projects?.forEach(proj => {
        let project = {};
        project.id = proj.id?.trim() || "";
        project.enabled = +(proj.enabled || 0);
        project.data = {};
        if (project.id === "opm-social") {
          project.data.OPMCohort = proj.data?.OPMCohort?.trim() || "";
          project.data.location = proj.data?.location?.trim() || "";
          project.data.business = proj.data?.business?.trim() || "";
          project.data.travelsALotTo = proj.data?.travelsALotTo?.trim() || "";
          project.data.travelPlans = proj.data?.travelPlans?.trim() || "";
          project.data.bio = proj.data?.bio?.trim() || "";
        }
        set.data.projects.push(project);
      });
      
      let existsUser = existsUsers.find(u => +(user.id || 0) === u.id);
      if (existsUser && existsUser.data.role) set.data.role = existsUser.data.role;

      let query = "UPDATE `users` SET ", queryParamNames = [], queryParams = [];
      for (let param in set) {
        queryParamNames.push("`" + param + "`=?");
        queryParams.push(param === "data"? JSON.stringify(set[param]): set[param]);
      }

      if (existsUser) {
        query += queryParamNames.join(",") + " WHERE `id`=?";
        queryParams.push(existsUser.id);
        let [updateResult] = await res.locals.db.query(query, queryParams);
      }
      users.push({ id: existsUser.id || user.id, ...set });

      if (existsUser && existsUser.id === req.user.id) {
        req.user = { ...req.user, ...set };
        delete req.user.hash;
        delete req.user.salt;
        
        req.session.passport.user = req.user;
        req.session.save(function (err) {
          if (err) console.log(err);
        });
      }
    });

    [rows] = images.length && await res.locals.db.query("SELECT * FROM images WHERE id IN (?)", [images]);
    images = [];
    if (rows && rows.length) {
      for (let i = 0; i < rows.length; i++) {
        let img = { ...rows[i] };
        let thumbnail = await res.locals.images.getResized(img.id, "thumbnail");
        img.url = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
        images.push(img);
      }
    }

    //console.log(JSON.stringify(users));
    return res.render('admin/users-edit', {
      user: req.user,
      users: users,
      images: images,
    });
  }
  catch {
    return next();
  }
});


router.post("/users/:id/avatar/upload", function (req, res, next) {
  res.locals.images.avatarUpload(req, res, async function (err) {
    if (err) {
      console.log(err);
      res.send({ error: err })
    }
    else {
      try {
        let id = await res.locals.images.save({
          filename: req.file.filename,
          filename_original: req.file.originalname,
          size: req.file.size,
          user_id: req.params.id
        })
        if (id) {
          let thumbnail = await res.locals.images.getResized(id, "thumbnail");
          res.send({ success: "Image uploaded.", id: id, url: thumbnail.url });
        }
        else res.send({ error: "Image not uploaded." });
      }
      catch (err) {
        console.log(err);
        res.send({ error: "Image not uploaded." })
      }
    }
  })
});

router.get('/applications/', adminAccess, function(req, res, next) {
  res.locals.db.query('SELECT * FROM applications WHERE 1', [])
  .then( ([rows, fields]) => {
    let applications = [];
    rows.forEach(row => {
      applications.push(row);
    });
    res.render('admin/applications', {
      user: req.user,
      applications: applications,
    });
  })
  .catch(error => {
    return next(error);
  });
});

router.get('/applications/:id/edit', adminAccess, async function(req, res, next) {
  try {
    let application;
    let [rows] = await res.locals.db.query('SELECT * FROM applications WHERE id=?', [req.params.id]);
    if (rows && rows.length) {
      rows[0].data = JSON.parse(rows[0].data);
      application = rows[0];
    }
    res.render('admin/applications-edit' + (application.project_id === 3? "": "-simple"), {
      user: req.user,
      application: application,
    });
  }
  catch {
    return next();
  }
});

router.post('/applications/:id/edit', adminAccess, async function(req, res, next) {
  try {
    let existsApplication;
    let [rows] = await res.locals.db.query('SELECT * FROM applications WHERE id=? LIMIT 1', [req.params.id]);
    if (rows && rows.length) {
      rows[0].data = JSON.parse(rows[0].data);
      existsApplication = rows[0];
    }

    let application;
    let set = {};
    set.status = req.body.application.status?.trim() || "";
    set.data = {};
    set.data.fullName = req.body.application.data?.fullName?.trim() || "";
    set.data.occupationAndTitle = req.body.application.data?.occupationAndTitle?.trim() || "";
    set.data.email = req.body.application.data.email || "";
    set.data.phone = req.body.application.data.phone || "";

    if (existsApplication.project_id === 3) {
      let business = [];
      let otherBusiness = [];
      let businessFiler = config.projects["opm-social"].application.properties.find(p => p.name === "business").values;
      req.body.application.data?.business?.forEach((val, i) => {
        if (businessFiler.includes(val)) {
          if (! business.includes(val)) business.push(val);
        }
        else if (val && businessFiler.includes("Other")) {
          if (! business.includes("Other")) business.push("Other");
          if (! otherBusiness.includes(val)) otherBusiness.push(val);
        }
      });
      (req.body.application.data?.otherBusiness?.trim() || "").split(";").forEach((val, i) => {
        val = val.trim();
        if (businessFiler.includes(val)) {
          if (! business.includes(val)) business.push(val);
        }
        else if (val && businessFiler.includes("Other")) {
          if (! otherBusiness.includes(val)) otherBusiness.push(val);
        }
      });
      if (req.body.application.data?.otherBusiness && ! otherBusiness.length) {
        let i = business.indexOf("Other");
        if (i >= 0) business.splice(i, 1);
      }
      set.data.business = business;
      set.data.otherBusiness = otherBusiness.join("; ");
      set.data.location = req.body.application.data?.location?.trim() || "";
      set.data.hangoutSpots = req.body.application.data?.hangoutSpots?.trim() || "";
      set.data.clubMemberships = req.body.application.data?.clubMemberships?.trim() || "";
      set.data.OPMAlumnus = +(req.body.application.data?.OPMAlumnus?.trim() || 0);
      set.data.businessIsBig = +(req.body.application.data?.businessIsBig?.trim() || 0);
      set.data.alumnusName = req.body.application.data.alumnusName || "";
      set.data.alumnusEmail = req.body.application.data.alumnusEmail || "";
      set.data.travelPlans = req.body.application.data.travelPlans || "";
      set.data.comments = req.body.application.data.comments || "";
    }

    let query = "UPDATE `applications` SET ", queryParamNames = [], queryParams = [];
    for (let param in set) {
      queryParamNames.push("`" + param + "`=?");
      queryParams.push(param === "data"? JSON.stringify(set[param]): set[param]);
    }

    if (existsApplication) {
      if (set.status !== existsApplication.status) {
        queryParamNames.push("`status_changed_at`=?");
        queryParams.push(new Date());
      }
      query += queryParamNames.join(",") + " WHERE `id`=?";
      queryParams.push(existsApplication.id);
      let [updateResult] = await res.locals.db.query(query, queryParams);
      application = { ...existsApplication, ...set };
    }

    return res.render('admin/applications-edit' + (application.project_id === 3? "": "-simple"), {
      user: req.user,
      application: application,
    });
  }
  catch (error) {
    return next(error);
  }
});

module.exports = router;
