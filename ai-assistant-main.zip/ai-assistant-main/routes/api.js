const express = require('express');
const app = express();
const cors = require('cors');
const fetch = require('isomorphic-fetch');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require("multer");
//const imageSize = require('image-size');
const sharp = require('sharp');
//import OpenAI from 'openai';
const OpenAI = require('openai');

const config = require('../config/app');

config.openAI = {
  api: require('../config/api.openai'),
};

config.google = {
  customSearch: {
    api: require('../config/api.customsearch.google'),
  },
};

const openai = new OpenAI({
  apiKey: config.openAI.api.key,
});

app.use(express.json());
app.use(cors());

app.get('/google/customsearch', (req, res) => {
  let url = `${config.google.customSearch.api.endpoint}?key=${config.google.customSearch.api.key}&cx=${config.google.customSearch.api.cx}&searchType=image`;
  if (req.query) for (let o in req.query) url += "&" + encodeURIComponent(o) + "=" + encodeURIComponent(req.query[o]);
  fetch(url)
  .then(response => {
    res.setHeader('Content-Type', response.headers.get('content-type'));
    response.body.pipe(res);
  })
  .catch(error => {
    console.error(error);
    res.status(500).json({ error: 'Network error' });
  });
});

app.post('/openai/completions', async (req, res) => {
  /*const body = {
    prompt: req.body.prompt,
    model: config.openAI.api.completions.model,
    max_tokens: config.openAI.api.completions.maxTokens,
    temperature: req.body.temperature || config.openAI.api.completions.temperature,
    top_p: 1,
    n: 1,
    stream: false,
    logprobs: null,
    stop: "\n\n"
  }
  fetch(config.openAI.api.completions.endpoint, {
    method: 'POST',
    headers: {
      "Authorization": `Bearer ${config.openAI.api.key}`,
      "Content-Type": "application/json",
      "Accept": "application/json",
    },
    body: JSON.stringify(body)
  })
  .then(response => {
    res.setHeader('Content-Type', response.headers.get('content-type'));
    //res.setHeader('X-Content-Type-Options', 'nosniff');
    response.body.pipe(res);
  })
  .catch(error => {
    console.error(error);
    res.status(500).json({ error: 'Network error' });
  });*/
  
  const params = {
    prompt: req.body.prompt,
    model: config.openAI.api.completions.model,
    max_tokens: config.openAI.api.completions.maxTokens,
    temperature: req.body.temperature || config.openAI.api.completions.temperature,
    top_p: 1,
    n: 1,
    stream: false,
    logprobs: null,
    stop: "\n\n"
  };

  try {
    if (params.stream) {
      const stream = await openai.completions.create(params);
      res.setHeader('Content-Type', 'text/plain');
      for await (const part of stream) {
        res.write('data:' + JSON.stringify(part) + '\n');
      }
      res.end('\n');
    }
    else {
      const response = await openai.completions.create(params);
      res.send(JSON.stringify(response) + '\n');
    }
  }
  catch (error) {
    handleError(res, error);
  }
});

const userFlatProps = async (user, projectId, locals) => {
  let u = JSON.parse(JSON.stringify(user));
  u = {
    ...u,
    ...(u.data || {}),
    ...(projectId && u.data?.projects?.find(p => p.id === projectId)?.data || {})
  };
  delete u.notes;
  delete u.data;

  u.name = u.firstName;
  u.fullName = u.firstName + (u.lastName? " " + u.lastName: "");
  if (u.avatarFileName) u.avatarUrl = config.baseUrl + "images/" + u.avatarFileName;
  else u.avatarUrl = config.baseUrl + "images/user.png";
  if (typeof u.avatarId !== "undefined") {
    let thumbnail = await locals.images.getResized(u.avatarId, "thumbnail");
    u.avatarUrl = thumbnail? thumbnail.url: config.baseUrl + "images/user.png";
  }
  return u;
};

app.post('/openai/chat/completions', async (req, res) => {
  let projectConfig;
  let user = await userFlatProps(req.user, req.body.projectId, res.locals);
  
  if (user.enabled) {
    if (req.body.projectId && config.projects?.[req.body.projectId]?.enabled) {
      projectConfig = config.projects[req.body.projectId];
      projectConfig.category = req.body.categoryId && projectConfig.categories?.find(cat => cat.id === req.body.categoryId);
    }
    if (! projectConfig || ! projectConfig.category) {
      res.status(500).json({ error: 'Request error.' });
      return;
    }
  }
  else {
    res.status(500).json({ error: 'Access denied.' });
    return;
  }

  /*const body = {
    messages: req.body.messages,
    model: config.openAI.api.chatCompletions.model,
    max_tokens: config.openAI.api.chatCompletions.maxTokens,
    temperature: req.body.temperature || config.openAI.api.chatCompletions.temperature,
    top_p: 1,
    stream: true
  }
  let instructions = projectConfig.category.chatInstructions || projectConfig.chatInstructions || "";
  instructions = instructions.replaceAll(/\{\{category\.([\w-]+)\}\}/g, (m, p1) => projectConfig.category[p1] || "undefined");
  instructions = instructions.replaceAll(/\{\{user\.([\w-]+)\}\}/g, (m, p1) => user?.[p1] || "undefined");
  instructions = instructions.replaceAll(/\{\{datetime\}\}/g, (m) => (new Date()).toGMTString());
  body.messages.unshift({
    role: "system",
    content: instructions
  });
  fetch(config.openAI.api.chatCompletions.endpoint, {
    method: 'POST',
    headers: {
      "Authorization": `Bearer ${config.openAI.api.key}`,
      "Content-Type": "application/json",
      "Accept": "application/json",
    },
    body: JSON.stringify(body)
  })
  .then(response => {
    res.setHeader('Content-Type', response.headers.get('content-type'));
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Accel-Buffering', 'no');
    res.setHeader('Keep-Alive', 'timeout=5');
    response.body.pipe(res);
  })
  .catch(error => {
    console.error(error);
    res.status(500).json({ error: 'Network error' });
  });*/

  const params = {
    messages: req.body.messages,
    model: config.openAI.api.chatCompletions.model,
    max_tokens: config.openAI.api.chatCompletions.maxTokens,
    temperature: req.body.temperature || config.openAI.api.chatCompletions.temperature,
    top_p: 1,
    stream: true
  }
  let instructions = projectConfig.category.chatInstructions || projectConfig.chatInstructions || "";
  instructions = instructions.replaceAll(/\{\{category\.([\w-]+)\}\}/g, (m, p1) => projectConfig.category[p1] || "undefined");
  instructions = instructions.replaceAll(/\{\{user\.([\w-]+)\}\}/g, (m, p1) => user?.[p1] || "undefined");
  instructions = instructions.replaceAll(/\{\{datetime\}\}/g, (m) => (new Date()).toGMTString());
  params.messages.unshift({
    role: "system",
    content: instructions
  });
  try {
    if (params.stream) {
      const stream = await openai.chat.completions.create(params);
      res.setHeader('Content-Type', 'text/plain');
      res.setHeader('Transfer-Encoding', 'chunked');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('X-Accel-Buffering', 'no');
      res.setHeader('Keep-Alive', 'timeout=5');
      for await (const chunk of stream) {
        const chunkStr = JSON.stringify(chunk);
        //console.log(chunkStr)
        if ((chunk.object || "") === "chat.completion.chunk") {
          if (! req.session.openai) req.session.openai = {};
          if (! req.session.openai.completions) req.session.openai.completions = [];
          let completion = req.session.openai.completions.find(c => c.id === chunk.id);
          let choice;
          if (completion) {
            choice = completion.choices?.find(c => c.index === chunk.choices[0].index);
            if (choice) {
              if (! choice.message) choice.message = chunk.choices[0]?.delta;
              else choice.message.content += chunk.choices[0]?.delta?.content || "";
            }
            else {
              if (! completion.choices) completion.choices = [];
              choice = chunk.choices[0];
              if (choice && ! choice.message) {
                choice.message = choice.delta;
                delete(choice.delta);
              }
              completion.choices.push(choice);
            }
          }
          else {
            completion = chunk;
            if (completion.choices?.[0]) {
              completion.choices[0].message = completion.choices[0].delta;
              delete(completion.choices[0].delta);
            }
            req.session.openai.completions.push(completion);
          }
          if (chunk.choices[0].finish_reason) {
            completion.choices[0].finish_reason = chunk.choices[0].finish_reason;
            completion.object = "chat.completion";
            //console.log(JSON.stringify(completion))
          }
          req.session.save(function (err) {
            if (err) console.log(err);
          });
        }
        res.write('data:' + chunkStr + '\n');
      }
      res.end('\n');
    }
    else {
      const response = await openai.chat.completions.create(params);
      console.log(JSON.stringify(response))
      res.send(JSON.stringify(response) + '\n');
    }
  }
  catch (error) {
    handleError(res, error);
  }
});

const handleError = (res, error) => {
  if (error instanceof OpenAI.APIError) {
    const status = error.status !== undefined ? error.status : 500
    res.status(status).send(
      JSON.stringify(
        {
          message: error.message,
          code: error.code,
          type: error.type
        },
        null,
        2
      ) + '\n'
    )
  } else {
    res.status(error.status || 500).send(
      JSON.stringify(
        {
          message:
            'Error: ' +
            (error.message || 'An unknown, non-API related error occurred.')
        },
        null,
        2
      ) + '\n'
    )
  }
}

app.post('/user/profile', async (req, res) => {
  if (req.user?.enabled) {
    if (req.body.action === "get" || req.body.action === "update") {
      let user = await userFlatProps(req.user, req.body.projectId, res.locals);
      let project = (req.body.projectId && config.projects[req.body.projectId]) || {};
      let messages = [];

      if (req.body.action === "update") {
        let set = {
          data: JSON.parse(JSON.stringify(req.user.data)),
        };
        project.profile.properties.forEach(prop => {
          let value = req.body.user[prop.name];
          if (! prop.enablable || typeof value !== "undefined") {
            if (prop.type === "text" || prop.type === "string" || prop.type === "email" || prop.type === "password") value = typeof value === "string"? value.trim(): "";
            else if (prop.type === "number") value = typeof value === "string"? +(value.trim()): "";
            if (prop.required && ! value.length) messages.push({ message: `Please enter your ${prop.title}.`, type: "error", for: `user[${prop.name}]` });
            else if (prop.minLength && value.length < prop.minLength) messages.push({ message: `The length of the ${prop.title} must be at least ${prop.minLength} character${prop.minLength === 1? '': 's'}.`, type: "error", for: `user[${prop.name}]` });
            else if (prop.maxLength && value.length > prop.maxLength) messages.push({ message: `The length of the ${prop.title} must be less than ${prop.maxLength} character${prop.maxLength === 1? '': 's'}.`, type: "error", for: `user[${prop.name}]` });
            else if (prop.type === "email" && ! value.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) messages.push({ message: `The ${prop.title} must be a valid email address.`, type: "error", for: `user[${prop.name}]` });
            if (prop.inherited) {
              if (["username", "password"].includes(prop.name)) set[prop.name] = value;
              else set.data[prop.name] = value;
            }
            else {
              if (! set.data.projects) set.data.projects = [];
              if (! set.data.projects.find(p => p.id === req.body.projectId)) set.data.projects.push({ id: req.body.projectId, data: {} });
              if (! set.data.projects.find(p => p.id === req.body.projectId).data) set.data.projects.find(p => p.id === req.body.projectId).data = {};
              set.data.projects.find(p => p.id === req.body.projectId).data[prop.name] = value;
            }
          }
        });
        user = { ...user, ...await userFlatProps(set, req.body.projectId, res.locals) };
        delete user.password;
        delete user.hash;
        delete user.salt;
        delete user.avatarFileName;

        if (! messages.length) {
          if (typeof set.password !== "undefined") {
            const pass = res.locals.auth.hashPassword(set.password);
            set.hash = pass.hash;
            set.salt = pass.salt;
            delete set.password;
          }
          try {
            let query = "UPDATE `users` SET ", queryParamNames = [], queryParams = [];
            for (let param in set) {
              queryParamNames.push("`" + param + "`=?");
              queryParams.push(param === "data"? JSON.stringify(set[param]): set[param]);
            }
            query += queryParamNames.join(",") + " WHERE `id`=?";
            queryParams.push(req.user.id);

            let [updateResult] = await res.locals.db.query(query, queryParams);
            if (updateResult) {
              messages.push({ message: "Profile updated.", type: "success" });
              req.user = { ...req.user, ...set };
              delete req.user.hash;
              delete req.user.salt;
              
              req.session.passport.user = req.user;
              req.session.save(function (err) {
                if (err) console.log(err);
              });
            }
            else {
              messages.push({ message: "Profile not updated.", type: "error" });
            }
          }
          catch {
            messages.push({ message: "Profile not updated.", type: "error" });
          }
        }
        else {
          messages.push({ message: (messages.length < 2? "An error": messages.length + " errors") + " have been detected in the form.", type: "error", for: "" });
        }
      }

      if (req.body.contentType === "html") {
        app.render('profile', { messages: messages, user: user, project: project, config: config }, (err, html) => {
          //console.log(err)
          if (err) res.status(500).json({ error: 'Request error.' });
          else res.status(200).json({ html: html, user: user });
        });
      }
      else res.status(200).json({ error: 'Request error.' });
    }
  }
  else {
    res.status(500).json({ error: 'Access denied.' });
    return;
  }
});


app.post("/user/avatar/upload", function (req, res, next) {
  res.locals.images.avatarUpload(req, res, async function (err) {
    if (err) {
      console.log(err);
      res.send({ error: err })
    }
    else {
      try {
        let id = await res.locals.images.save({
          filename: req.file.filename,
          filename_original: req.file.originalname,
          size: req.file.size,
          user_id: req.user.id
        })
        if (id) {
          let thumbnail = await res.locals.images.getResized(id, "thumbnail");
          res.send({ success: "Image uploaded.", id: id, url: thumbnail.url });
        }
        else res.send({ error: "Image not uploaded." });
      }
      catch (err) {
        console.log(err);
        res.send({ error: "Image not uploaded." });
      }
    }
  })
});

module.exports = app;
