(function () {
"use strict";

const AI = {};

window.AI = AI;

AI.config = {};

AI.config.categoryList = "#categories";
AI.config.chatContainer = "#chat";
AI.config.messagesContainer = "#chatMessages";
AI.config.infoContainer = "#chatInfo";
AI.config.footerContainer = "#chatFooter";
AI.config.sendMessageForm = "#sendMessageForm";
AI.config.sendMessageTextInput = "#sendMessageTextInput";
AI.config.sendMessageButton = "#sendMessageButton";
AI.config.messageStopButton = "#messageStopButton";
AI.config.messageRegenerateButton = "#messageRegenerateButton";
AI.config.userMenu = "#chatHeaderUserMenu";


AI.config.openAIAPIEndpoint = "https://api.openai.com/v1/completions";
AI.config.openAIAPIChatEndpoint = "https://api.openai.com/v1/chat/completions";
AI.config.googleCustomSearchAPIEndpoint = "https://customsearch.googleapis.com/customsearch/v1";

AI.config.chatMessageRoles = {
  system: { avatarHTML: "<svg><use href=\"#chatSystemAvatar\"/></svg>", visible: false },
  user: { avatarHTML: "<svg><use href=\"#chatUserAvatar\"/></svg>" },
  assistant: { avatarHTML: "<svg><use href=\"#chatAIAvatar\"/></svg><div class=\"messageLoadingIcon\"><svg><use href=\"#messageLoadingIcon\"/></svg></div>" },
  error: { avatarHTML: "<svg><use href=\"#chatWarningAvatar\"/></svg>", sendible: false },
};

const IMAGE_REGEX = /\!\[([^\[\]]*?)\]\(([^\(\)]*?)\)/g;
const IMAGE_PARTIAL_REGEX = /\!\[[^\[\]]*?\]\([^\)]*$/;

const EMOJI_REGEX = /[#*0-9]\uFE0F?\u20E3|[\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23ED-\u23EF\u23F1\u23F2\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB\u25FC\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692\u2694-\u2697\u2699\u269B\u269C\u26A0\u26A7\u26AA\u26B0\u26B1\u26BD\u26BE\u26C4\u26C8\u26CF\u26D1\u26D3\u26E9\u26F0-\u26F5\u26F7\u26F8\u26FA\u2702\u2708\u2709\u270F\u2712\u2714\u2716\u271D\u2721\u2733\u2734\u2744\u2747\u2757\u2763\u27A1\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B55\u3030\u303D\u3297\u3299]\uFE0F?|[\u261D\u270C\u270D](?:\uFE0F|\uD83C[\uDFFB-\uDFFF])?|[\u270A\u270B](?:\uD83C[\uDFFB-\uDFFF])?|[\u23E9-\u23EC\u23F0\u23F3\u25FD\u2693\u26A1\u26AB\u26C5\u26CE\u26D4\u26EA\u26FD\u2705\u2728\u274C\u274E\u2753-\u2755\u2795-\u2797\u27B0\u27BF\u2B50]|\u26F9(?:\uFE0F|\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|\u2764\uFE0F?(?:\u200D(?:\uD83D\uDD25|\uD83E\uDE79))?|\uD83C(?:[\uDC04\uDD70\uDD71\uDD7E\uDD7F\uDE02\uDE37\uDF21\uDF24-\uDF2C\uDF36\uDF7D\uDF96\uDF97\uDF99-\uDF9B\uDF9E\uDF9F\uDFCD\uDFCE\uDFD4-\uDFDF\uDFF5\uDFF7]\uFE0F?|[\uDF85\uDFC2\uDFC7](?:\uD83C[\uDFFB-\uDFFF])?|[\uDFC3\uDFC4\uDFCA](?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDFCB\uDFCC](?:\uFE0F|\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDCCF\uDD8E\uDD91-\uDD9A\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF84\uDF86-\uDF93\uDFA0-\uDFC1\uDFC5\uDFC6\uDFC8\uDFC9\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF8-\uDFFF]|\uDDE6\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF]|\uDDE7\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF]|\uDDE8\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF5\uDDF7\uDDFA-\uDDFF]|\uDDE9\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF]|\uDDEA\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA]|\uDDEB\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7]|\uDDEC\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE]|\uDDED\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA]|\uDDEE\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9]|\uDDEF\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5]|\uDDF0\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF]|\uDDF1\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE]|\uDDF2\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF]|\uDDF3\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF]|\uDDF4\uD83C\uDDF2|\uDDF5\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE]|\uDDF6\uD83C\uDDE6|\uDDF7\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC]|\uDDF8\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF]|\uDDF9\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF]|\uDDFA\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF]|\uDDFB\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA]|\uDDFC\uD83C[\uDDEB\uDDF8]|\uDDFD\uD83C\uDDF0|\uDDFE\uD83C[\uDDEA\uDDF9]|\uDDFF\uD83C[\uDDE6\uDDF2\uDDFC]|\uDFF3\uFE0F?(?:\u200D(?:\u26A7\uFE0F?|\uD83C\uDF08))?|\uDFF4(?:\u200D\u2620\uFE0F?|\uDB40\uDC67\uDB40\uDC62\uDB40(?:\uDC65\uDB40\uDC6E\uDB40\uDC67|\uDC73\uDB40\uDC63\uDB40\uDC74|\uDC77\uDB40\uDC6C\uDB40\uDC73)\uDB40\uDC7F)?)|\uD83D(?:[\uDC08\uDC26](?:\u200D\u2B1B)?|[\uDC3F\uDCFD\uDD49\uDD4A\uDD6F\uDD70\uDD73\uDD76-\uDD79\uDD87\uDD8A-\uDD8D\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA\uDECB\uDECD-\uDECF\uDEE0-\uDEE5\uDEE9\uDEF0\uDEF3]\uFE0F?|[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC6B-\uDC6D\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDC8F\uDC91\uDCAA\uDD7A\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC](?:\uD83C[\uDFFB-\uDFFF])?|[\uDC6E\uDC70\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6](?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDD74\uDD90](?:\uFE0F|\uD83C[\uDFFB-\uDFFF])?|[\uDC00-\uDC07\uDC09-\uDC14\uDC16-\uDC25\uDC27-\uDC3A\uDC3C-\uDC3E\uDC40\uDC44\uDC45\uDC51-\uDC65\uDC6A\uDC79-\uDC7B\uDC7D-\uDC80\uDC84\uDC88-\uDC8E\uDC90\uDC92-\uDCA9\uDCAB-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDDA4\uDDFB-\uDE2D\uDE2F-\uDE34\uDE37-\uDE44\uDE48-\uDE4A\uDE80-\uDEA2\uDEA4-\uDEB3\uDEB7-\uDEBF\uDEC1-\uDEC5\uDED0-\uDED2\uDED5-\uDED7\uDEDC-\uDEDF\uDEEB\uDEEC\uDEF4-\uDEFC\uDFE0-\uDFEB\uDFF0]|\uDC15(?:\u200D\uD83E\uDDBA)?|\uDC3B(?:\u200D\u2744\uFE0F?)?|\uDC41\uFE0F?(?:\u200D\uD83D\uDDE8\uFE0F?)?|\uDC68(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDC68\uDC69]\u200D\uD83D(?:\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?)|[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?)|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C(?:\uDFFB(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83D\uDC68\uD83C[\uDFFC-\uDFFF])))?|\uDFFC(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83D\uDC68\uD83C[\uDFFB\uDFFD-\uDFFF])))?|\uDFFD(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83D\uDC68\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])))?|\uDFFE(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83D\uDC68\uD83C[\uDFFB-\uDFFD\uDFFF])))?|\uDFFF(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83D\uDC68\uD83C[\uDFFB-\uDFFE])))?))?|\uDC69(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?[\uDC68\uDC69]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?|\uDC69\u200D\uD83D(?:\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?))|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C(?:\uDFFB(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFC-\uDFFF])))?|\uDFFC(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB\uDFFD-\uDFFF])))?|\uDFFD(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])))?|\uDFFE(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB-\uDFFD\uDFFF])))?|\uDFFF(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB-\uDFFE])))?))?|\uDC6F(?:\u200D[\u2640\u2642]\uFE0F?)?|\uDD75(?:\uFE0F|\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|\uDE2E(?:\u200D\uD83D\uDCA8)?|\uDE35(?:\u200D\uD83D\uDCAB)?|\uDE36(?:\u200D\uD83C\uDF2B\uFE0F?)?)|\uD83E(?:[\uDD0C\uDD0F\uDD18-\uDD1F\uDD30-\uDD34\uDD36\uDD77\uDDB5\uDDB6\uDDBB\uDDD2\uDDD3\uDDD5\uDEC3-\uDEC5\uDEF0\uDEF2-\uDEF8](?:\uD83C[\uDFFB-\uDFFF])?|[\uDD26\uDD35\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD4\uDDD6-\uDDDD](?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDDDE\uDDDF](?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDD0D\uDD0E\uDD10-\uDD17\uDD20-\uDD25\uDD27-\uDD2F\uDD3A\uDD3F-\uDD45\uDD47-\uDD76\uDD78-\uDDB4\uDDB7\uDDBA\uDDBC-\uDDCC\uDDD0\uDDE0-\uDDFF\uDE70-\uDE7C\uDE80-\uDE88\uDE90-\uDEBD\uDEBF-\uDEC2\uDECE-\uDEDB\uDEE0-\uDEE8]|\uDD3C(?:\u200D[\u2640\u2642]\uFE0F?|\uD83C[\uDFFB-\uDFFF])?|\uDDD1(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83E\uDDD1))|\uD83C(?:\uDFFB(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFC-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF])))?|\uDFFC(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB\uDFFD-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF])))?|\uDFFD(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF])))?|\uDFFE(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB-\uDFFD\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF])))?|\uDFFF(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB-\uDFFE]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF-\uDDB3\uDDBC\uDDBD]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF])))?))?|\uDEF1(?:\uD83C(?:\uDFFB(?:\u200D\uD83E\uDEF2\uD83C[\uDFFC-\uDFFF])?|\uDFFC(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB\uDFFD-\uDFFF])?|\uDFFD(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])?|\uDFFE(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB-\uDFFD\uDFFF])?|\uDFFF(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB-\uDFFE])?))?)/g;

const IMAGE_LOADER_DATAURI = 'data:image/svg+xml;base64,' +
  btoa(unescape(encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300" viewBox="0 0 300 300">\
  <rect x="0.5" y="0.5" width="299" height="299" rx="6" fill="none" stroke="#5E697C"/>\
  <g transform="scale(1.58 1.58) translate(77 77)" fill="none" stroke="#5E697C" stroke-width="1">\
    <circle stroke-opacity=".125" cx="18" cy="18" r="18"/>\
    <path d="M36 18c0-9.94-8.06-18-18-18">\
      <animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur="1s" repeatCount="indefinite"/>\
    </path>\
  </g>\
</svg>')));



AI.imageSearch = function (query, options, success, error) {
  let url = `${AI.config.googleCustomSearchAPIEndpoint}?q=${query}&searchType=image`;
  if (options) for (let o in options) url += "&" + encodeURIComponent(o) + "=" + encodeURIComponent(options[o]);
  fetch(url)
    .then(response => response.json())
    .then(data => typeof success === "function"? success(data.items): void 0)
    .catch(err => typeof error === "function"? error(err): console.error(err));
}

AI.imageLoader = {
  images: [],
  nextId: 1,
};

AI.imageLoader.init = function (element) {
  element.querySelectorAll(".imageLoader").forEach(element => {
    if (! element.getAttribute('data-loader-id')) {
      const id = this.nextId++,
        image = {
          id: id,
          element: element,
          searchQuery: (element.getAttribute('alt') || "").trim(),
          items: [],
          onSuccess: [],
          onError: [],
        };
      image.onSuccess.push((items) => {
        if (items && items.length) {
          image.items = items;
          //image.element.setAttribute("src", image.items[0].link);
          let query = `You need to find in the list of images the element that best matches the request: ${image.searchQuery}. Output the number of the element without explanations. List:`;
          image.items.forEach((item, index) => query += `\n${index + 1}. ${item.title}`);
          query += "\n\n";
          AI.completion(query, (answer) => {
            const a = answer && answer.match(/\d+/), img = a && image.items[parseInt(a) - 1];
            if (img) image.element.setAttribute("src", img.link);
            AI.scrollingDown();
          });
        }
        image.loaded = true;
        image.success = true;
      });
      image.onError.push((error) => {
        image.loaded = true;
        image.error = error || true;
        console.error(error);
      });
      element.setAttribute('data-loader-id', id);
      this.images.push(image);
      
      const loadedImage = this.images.find(i => i.loaded && i.searchQuery === image.searchQuery);
      if (loadedImage) {
        if (loadedImage.error) while (image.onError.length) image.onError.shift()(loadedImage.error);
        else while (image.onSuccess.length) image.onSuccess.shift()(loadedImage.items);
      }
      else {
        const loadingImage = this.images.find(i => i.id !== image.id && i.searchQuery === image.searchQuery);
        if (loadingImage) {
          loadingImage.onSuccess.push((items) => {
            while (image.onSuccess.length) image.onSuccess.shift()(items);
          });
          loadingImage.onError.push((error) => {
            while (image.onError.length) image.onError.shift()(error);
          });
        }
        else {
          AI.imageSearch(image.searchQuery,
            {
              num: 10,
              imgSize: "large",
              safe: "active"
            },
            (items) => {
              while (image.onSuccess.length) image.onSuccess.shift()(items);
            },
            (error) => {
              while (image.onError.length) image.onError.shift()(error);
            }
          );
        }
      }
    }
  });
}

AI.completionCache = [];

AI.completion = function (prompt, onSuccess, onError) {
  let cache = AI.completionCache.find(q => q.prompt === prompt);
  if (cache && cache.success) {
    onSuccess(cache.answer);
  }
  else {
    if (! cache) {
      cache = {
        prompt: prompt,
        onSuccess: [],
        onError: [],
      }
      AI.completionCache.push(cache);
    }
    if (onSuccess) cache.onSuccess.push(onSuccess);
    if (onError) cache.onError.push(onError);
    
    if (cache.loading) return false;
    cache.loading = true;
    
    const headers = {
      'Content-Type': 'application/json',
      "Accept": "application/json",
    };
    fetch(AI.config.openAIAPIEndpoint, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify({
        prompt: prompt,
        temperature: 0,
      })
    }).then(response => {
      return response.json();
    }).then(data => {
      cache.answer = data['choices'][0].text;
      cache.success = true;
      cache.loading = false;
      let f;
      while (f = cache.onSuccess.shift()) f(cache.answer);
      cache.onError = [];
    })
    .catch(error => {
      cache.success = false;
      cache.loading = false;
      let f;
      while (f = cache.onError.shift()) f(error);
      cache.onSuccess = [];
    });
  }
}

AI.chatCompletion = async (args) => {
  try {
    const headers = {
      'Content-Type': 'application/json',
      "Accept": "application/json",
    };
    const response = await fetch(AI.config.openAIAPIChatEndpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        messages: args.messages,
        categoryId: args.categoryId,
        projectId: args.projectId,
      }),
      signal: args.abortSignal || void 0,
    });

    let chunks = [];

    const reader = response.body.pipeThrough? response.body.pipeThrough(new TextDecoderStream()).getReader(): response.body.getReader();
    const decoder = new TextDecoder();

    async function read() {
      let { value, done } = await reader.read();
      if (done) return args.onAnswer(chunks);
      
      if (typeof value === "object" && value.buffer) value = decoder.decode(value);
      value.split(/\r\n|\n|\r/).forEach(chunk => {
        if (chunk.substr(0, 5) !== "data:") return;
        if (! (chunk = chunk.substr(5).trim()).match(/^\{.*\}$/)) {
            if (chunk === "[DONE]") return args.onAnswer(chunks);
            else return;
        }
        chunk = JSON.parse(chunk);
        if (chunk) {
          if (chunk) chunks.push(chunk);
          if (chunk?.choices?.[0]?.delta && ! chunk?.choices?.[0]?.finish_reason) {
            args.onAnswer(chunks);
          }
          else if ((chunk?.choices?.[0]?.finish_reason || "") === "length") {
            if (args.onError) args.onError("Token limit reached in the request.");
          }
        }
      })

      await read();
    }

    await read();
    return response;
  }
  catch (error) {
    if (args.onError) args.onError(error);
    return null;
  }
}

AI.categories = [];

AI.categoryNextId = function () {
  let maxId = 0;
  this.categories.forEach(category => {
    let id = category.id.match(/^\d+$/);
    if (id && (id = parseInt(id[0])) > maxId) maxId = id;
  });
  return (maxId + 1) + '';
}

AI.category = function (config) {
  if (! config) config = { id: AI.categoryNextId() };
  else if (typeof config !== 'object') config = { id: (typeof config === 'string' || typeof config === 'number'? config + '': AI.categoryNextId()) };
  if (typeof config.id === 'number') config.id = config.id + '';
  if (! config.id) config.id = AI.categoryNextId();
  
  const category = AI.categories.find(c => c.id === config.id);
  if (category) return category.config(config);
  
  if (! (this instanceof AI.category)) return new AI.category(config);
  
  this.config(config);
  AI.categories.push(this);
  return this;
}

AI.category.prototype.config = function (config, value) {
  let key;
  if (typeof config === 'string' && typeof value !== 'undefined') key = config, config = {}, config[key] = value, value = void 0;
  if (config) {
    if (typeof config === 'object' && ! Array.isArray(config)) {
      for (key in config) {
        this[key] = config[key];
      }
      this.enabled = typeof this.enabled === "undefined"? true: !! this.enabled;
      if (! AI.menuElement) {
        AI.menuElement = document.querySelector(AI.config.menu || "#menu");
        AI.menuIsOpened = false;
        AI.menuShow = function () { document.body.classList.add("menu-opened"); AI.menuIsOpened = true; };
        AI.menuHide = function () { document.body.classList.remove("menu-opened"); AI.menuIsOpened = false; };
      }
      const category = this;
      if (! this.categoryListElement) {
        this.categoryListElement = document.querySelector(this.categoryList) || AI.categoryListElement || (AI.categoryListElement = document.querySelector(AI.config.categoryList));
      }
      if (! this.categoryElement) {
        this.categoryElement = this.categoryListElement.querySelector(this.categoryList || `[data-category-id="${this.id}"].category`);
        if (! this.categoryElement) {
          this.categoryElement = document.createElement("li");
          this.categoryElement.setAttribute("class", "category");
          this.categoryElement.setAttribute("data-category-id", category.id);
          this.categoryElement.innerHTML = `<span class="caption"><svg class="icon"><use href="#catIcon_${category.id}"/></svg><span class="title">${category.title}</span><svg class="arrow"><use href="#catArrowDown"/></svg></span>`;
          this.categoryListElement.appendChild(this.categoryElement);
        }
      }
      if (this.categoryElement) {
        if (! this.chatListElement) {
          this.chatListElement = this.categoryElement.querySelector(this.chatList || AI.config.chatList || ".chats");
          if (! this.chatListElement) {
            this.chatListElement = document.createElement("ul");
            this.chatListElement.setAttribute("class", "chats");
            this.chatListElement.innerHTML = '<li class="newChat"><svg class="icon"><use href="#catNewChatIcon"/></svg> New project</li>';
            this.categoryElement.appendChild(this.chatListElement);
            
            this.chatNewElement = this.chatListElement.querySelector(".newChat");
            this.chatNewElement.addEventListener('click', (e) => {
              if (AI.menuIsOpened) AI.menuHide();
              const chat = AI.chats.find(c => ! c.messages.length || (c.messages.length < 2 && c.messages[0].role === "system")) || AI.chat({});
              chat.config({
                categoryId: category.id,
                messages: []
              }).show();
              chat.sendMessageTextInput.focus();
              return false;
            });
          }
        }
        if (! this.categoryCaptionElement) {
          this.categoryCaptionElement = this.categoryElement.querySelector(this.categoryCaption || AI.config.categoryCaption || ".caption");
          this.categoryCaptionElement.addEventListener('click', (e) => {
            category.visible? category.hide(): category.show();
            return false;
          });
        }
        if (! this.categoryArrowElement) {
          this.categoryArrowElement = this.categoryElement.querySelector(this.categoryArrow || AI.config.categoryArrow || ".arrow");
        }
        if (! AI.chatHeaderSubTitleElement) {
          AI.chatHeaderSubTitleElement = document.querySelector(AI.config.chatHeaderSubTitle || "#chatHeaderSubTitle");
          AI.chatHeaderSubTitleElement.addEventListener('click', (e) => {
            AI.menuIsOpened? AI.menuHide(): AI.menuShow();
            return false;
          });
          document.querySelector(AI.config.menuOpenedGround || "#menu_openedGround").addEventListener('click', (e) => {
            AI.menuHide();
            return false;
          });
          document.querySelector(AI.config.menuOpenedHide || "#menu_openedHide").addEventListener('click', (e) => {
            AI.menuHide();
            return false;
          });
        }
        if (! AI.categoryHeaderTitleElement) {
          AI.categoryHeaderTitleElement = document.querySelector(AI.config.categoryHeaderTitle || "#chatHeaderSubTitle .catTitle");
        }
        if (this.enabled) this.categoryElement.classList.remove("disabled");
        else this.categoryElement.classList.add("disabled");
        if (this.visible && this.enabled) {
          let c = AI.categoryId || this.categoryListElement.getAttribute("data-category-id");
          if (c && c !== this.id) AI.category(c).hide();
          AI.categoryId = this.id;
          this.categoryListElement.setAttribute("data-category-id", this.id);
          this.chatListElement.classList.remove("hidden");
          this.categoryArrowElement.innerHTML = '<use href="#catArrowUp"/>';
          let e = document.querySelector("#detailsTeacherName val");
          if (e) e.innerHTML = this.teacherName || "—";
          e = document.querySelector("#detailsNextLesson val");
          if (e) e.innerHTML = ((c = AI.categories.findIndex(c => c.id === this.id)) >= 0 && AI.categories[c + 1]?.title) || "—";
          AI.categoryHeaderTitleElement.innerHTML = this.title;
        }
        else {
          this.categoryListElement.removeAttribute("data-category-id");
          this.chatListElement.classList.add("hidden");
          this.categoryArrowElement.innerHTML = '<use href="#catArrowDown"/>';
        }
      }
    }
    else if (typeof value === 'undefined') {
      if (Array.isArray(config)) {
        let some = {};
        for (key in config) some[config[key]] = this[config[key]];
        return some;
      }
      else if (typeof config === 'string') {
        return this[config];
      }
    }
  }
  return this;
};

AI.category.prototype.show = function () {
  this.config("visible", true);
  return this;
}

AI.category.prototype.hide = function () {
  this.config("visible", false);
  return this;
}



AI.chats = [];

AI.chatNextId = function () {
  let maxId = 0;
  this.chats.forEach(chat => {
    let id = chat.id.match(/^\d+$/);
    if (id && (id = parseInt(id[0])) > maxId) maxId = id;
  });
  return (maxId + 1) + '';
}

AI.chat = function (config) {
  if (typeof config !== 'object') config = { id: typeof config === 'string' || typeof config === 'number'? config + '': AI.chatNextId() };
  if (typeof config.id === 'number') config.id = config.id + '';
  if (! config.id) config.id = AI.chatNextId();
  
  const chat = AI.chats.find(chat => chat.id === config.id);
  if (chat) return chat.config(config);
  
  if (! (this instanceof AI.chat)) return new AI.chat(config);
  
  this.config(config);
  AI.chats.push(this);
  return this;
}

AI.chat.prototype.config = function (config, value) {
  let key;
  if (typeof config === 'string' && typeof value !== 'undefined') key = config, config = {}, config[key] = value, value = void 0;
  if (config) {
    if (typeof config === 'object' && ! Array.isArray(config)) {
      for (key in config) {
        if (key === "messagesContainer") {
          if (this.messagesContainer && this.messagesContainer.getAttribute("data-chat-id") === (config.id || this.id)) {
            this.messagesContainer.removeAttribute("data-chat-id");
            this.messagesContainer.innerHTML = "";
          }
          delete this.messagesContainer;
          delete this.messagesContainer;
        }
        else if (key === "messages") {
          if (! config[key]) config[key] = [];
          if (this.messagesContainer) this.messagesContainer.innerHTML = "";
        }
        else if (key === "visible" && config[key]) {
          AI.chats.filter(chat => chat.visible && chat.id !== (config.id || this.id)).forEach(chat => chat.hide());
        }
        this[key] = config[key];
      }
      if (typeof this.messagesContainer !== "object") {
        this.messagesContainer = document.querySelector(this.messagesContainer || AI.config.messagesContainer);
      }
      if (! AI.chatHeaderTitleElement) {
        AI.chatHeaderTitleElement = document.querySelector(AI.config.chatHeaderTitle || "#chatHeaderSubTitle .chatTitle");
      }
      if (this.visible) {
        AI.chatId = this.id;
        if (this.messagesContainer.getAttribute("data-chat-id") !== this.id) {
          this.messagesContainer.setAttribute("data-chat-id", this.id);
          this.messagesContainer.innerHTML = "";
          AI.footerElement.classList.remove("message-has-answer");
        }
        if (this.chatListItemElement) this.chatListItemElement.classList.add("selected");
        AI.chatHeaderTitleElement.innerHTML = this.title || "New project";
      }
      else {
        if (this.chatListItemElement) this.chatListItemElement.classList.remove("selected");
      }
      if (! this.messages) this.messages = [];
      if (this.messages.length && ! this.messagesContainer.children?.length) {
        this.messages.splice(0).forEach(message => this.addMessage(message));
      }
      if (typeof this.sendMessageForm !== "object") {
        this.sendMessageForm = document.querySelector(this.sendMessageForm || AI.config.sendMessageForm);
        if (! this.sendMessageForm.getAttribute("data-initiated")) {
          this.sendMessageForm.addEventListener("submit", event => {
            event.preventDefault();
            let chat = AI.chat(AI.chatId);
            if (chat) {
              if (chat.response?.abort) chat.response.abort();
              chat.sendMessage(this.sendMessageTextInput.value);
              this.sendMessageTextInput.value = '';
              this.sendMessageTextInput.dispatchEvent(new Event('input'));
            }
            return false;
          }, false);
          this.sendMessageForm.setAttribute("data-initiated", true);
        }
      }
      if (typeof this.sendMessageButton !== "object") {
        this.sendMessageButton = document.querySelector(this.sendMessageButton || AI.config.sendMessageButton);
      }
      if (typeof this.sendMessageTextInput !== "object") {
        this.sendMessageTextInput = document.querySelector(this.sendMessageTextInput || AI.config.sendMessageTextInput);
        if (! this.sendMessageTextInput.getAttribute("data-initiated")) {
          const minHeight = this.sendMessageTextInput.getAttribute("data-minHeight") || 0;
          this.sendMessageTextInput.addEventListener("keydown", event => {
            if (event.key === "Enter" && ! event.shiftKey) {
              event.preventDefault();
              this.sendMessageForm.dispatchEvent(new Event('submit'));
            }
          });
          this.sendMessageTextInput.addEventListener("input", event => {
            this.sendMessageTextInput.style.height = '1px';
            this.sendMessageTextInput.style.height = Math.max(minHeight, this.sendMessageTextInput.scrollHeight) + 'px';
          });
          /*this.sendMessageTextInput.addEventListener("keyup", event => {
            if (this.sendMessageTextInput.scrollHeight > this.sendMessageTextInput.offsetHeight || this.sendMessageTextInput.scrollHeight + 4 < this.sendMessageTextInput.offsetHeight) {
              this.sendMessageTextInput.style.height = Math.max(minHeight, this.sendMessageTextInput.scrollHeight) + 'px';
            }
          });
          this.sendMessageTextInput.addEventListener("blur", event => {
            this.sendMessageTextInput.style.height = '1px';
            this.sendMessageTextInput.style.height = Math.max(minHeight, this.sendMessageTextInput.scrollHeight) + 'px';
          });*/
          this.sendMessageTextInput.style.height = Math.max(minHeight, this.sendMessageTextInput.scrollHeight) + 'px';
          this.sendMessageTextInput.setAttribute("data-initiated", true);
        }
      }
      if (typeof this.messageStopButton !== "object") {
        this.messageStopButton = document.querySelector(this.messageStopButton || AI.config.messageStopButton);
        if (! this.messageStopButton.getAttribute("data-initiated")) {
          this.messageStopButton.addEventListener("click", (event) => {
            event.preventDefault();
            let chat = AI.chat(AI.chatId);
            if (chat?.response?.abort) chat.response.abort();
          });
          this.messageStopButton.setAttribute("data-initiated", true);
        }
      }
      if (typeof this.messageRegenerateButton !== "object") {
        this.messageRegenerateButton = document.querySelector(this.messageRegenerateButton || AI.config.messageRegenerateButton);
        if (! this.messageRegenerateButton.getAttribute("data-initiated")) {
          this.messageRegenerateButton.addEventListener("click", (event) => {
            event.preventDefault();
            let chat = AI.chat(AI.chatId);
            if (chat?.response?.abort) chat.response.abort();
            let index = chat.messages.length;
            for (; --index > 0;) {
              if (chat.messages[index].role !== "user") {
                if (! chat.messages[index].removed) chat.removeMessage(index);
              }
              else if (! chat.messages[index].removed) break;
            }
            if (chat.messages.length && chat.messages[index].role === "user" && ! chat.messages[index].removed) {
              const content = chat.messages[index].content || "";
              chat.removeMessage(index);
              chat.sendMessage(content);
            }
          });
          this.messageRegenerateButton.setAttribute("data-initiated", true);
        }
      }
      if (typeof this.infoContainer !== "object") {
        this.infoContainer = document.querySelector(this.infoContainer || AI.config.infoContainer);
      }
      if (this.visible && ! this.messages.length) {
        this.infoContainer.classList.remove("hidden");
      }
    }
    else if (typeof value === 'undefined') {
      if (Array.isArray(config)) {
        let some = {};
        for (key in config) some[config[key]] = this[config[key]];
        return some;
      }
      else if (typeof config === 'string') {
        return this[config];
      }
    }
  }
  return this;
};

AI.chat.prototype.show = function () {
  this.config("visible", true);
  return this;
}

AI.chat.prototype.hide = function () {
  this.config("visible", false);
  return this;
}

AI.chat.prototype.removeMessage = function (index) {
  if (this.visible && ! this.messagesContainer) {
    console.error("Messages container is not defined.");
    return;
  }
  
  if (this.messages[index]) {
    this.messages[index].removed = true;
    
    if (this.visible) {
      const messageElement = this.messagesContainer.querySelector(`#message-${index}`);
      if (messageElement) messageElement.classList.add("hidden");

      if (! this.messages.filter(m => m.role === "assistant" && ! m.removed).length) AI.footerElement.classList.remove("message-has-answer");
    }
  }
}

AI.chat.prototype.addMessage = function (message) {
  if (this.visible && ! this.messagesContainer) {
    console.error("Messages container is not defined.");
    return;
  }
  
  if (typeof message === "string") message = {role: "user", content: message};
  if (typeof message !== "object" || ! message.role || ! AI.config.chatMessageRoles[message.role]) {
    console.error("Invalid message type.");
    return;
  }
  
  let messageIndex = this.messages.length;
  this.messages.push(message);
  
  let messageElement, contentElement, avatarElement;
  if (this.visible && ! message.removed && (typeof AI.config.chatMessageRoles[message.role].visible === "undefined" || AI.config.chatMessageRoles[message.role].visible)) {
    this.infoContainer.classList.add("hidden");
    
    AI.scrollDown = AI.scrollingDown(false);
    
    messageElement = document.createElement("div");
    messageElement.setAttribute("id", `message-${messageIndex}`);
    messageElement.setAttribute("class", `message ${message.role}-message`);
    this.messagesContainer.appendChild(messageElement);
    
    contentElement = document.createElement("div");
    contentElement.setAttribute("class", "message-content");
    let content = message.content || "";
    if (content && message.role !== "system") {
      content = content.replaceAll(IMAGE_REGEX, (t, name, url) => {
        name = name.trim();
        const image = AI.imageLoader.images.find(image => image.searchQuery === name && image.items.length);
        return '<img class="imageLoader" src="' + (image? image.items[0].link: IMAGE_LOADER_DATAURI) + '" alt="' + name + '"' + (image? ` data-loader-id="${image.id}"`: '') + '>';
      });
      content = marked.parse(content);
      content = content.replaceAll(EMOJI_REGEX, '<span class="emoji">$&</span>');
    }
    contentElement.innerHTML = content;
    messageElement.appendChild(contentElement);
    AI.imageLoader.init(contentElement);
    
    avatarElement = document.createElement("div");
    avatarElement.setAttribute("class", "message-avatar");
    avatarElement.innerHTML = AI.config.chatMessageRoles[message.role].avatarHTML;
    messageElement.appendChild(avatarElement);
    
    if (message.role === "assistant") AI.footerElement.classList.add("message-has-answer");
    
    AI.scrollingDown();
  }
  
  if (! this.categoryId && AI.categoryId) this.categoryId = AI.categoryId;
  const category = this.categoryId && AI.category(this.categoryId),
    chat = this;
  
  if (! this.chatListItemElement && category.chatListElement) {
    this.chatListItemElement = document.createElement("li");
    this.chatListItemElement.setAttribute("class", "chat" + (this.visible? " selected": ""));
    this.chatListItemElement.setAttribute("data-chat-id", this.id);
    this.chatListItemElement.innerHTML = '<svg class="icon"><use href="#catChatIcon"/></svg> <span class="chatTitle">' + (this.title || "...") + '</span>';
    category.chatListElement.appendChild(this.chatListItemElement);
    this.chatListItemTitleElement = this.chatListItemElement.querySelector(".chatTitle");
    
    this.chatListItemElement.addEventListener('click', (e) => {
      e.preventDefault();
      if (AI.menuIsOpened) AI.menuHide();
      chat.show();
      chat.sendMessageTextInput.focus();
    });
  }
  
  return {
    index: messageIndex,
    messageElement,
    contentElement,
  }
}

AI.chat.prototype.sendMessage = async function (message) {
  if (this.visible && ! this.messagesContainer) {
    console.error("Messages container is not defined.");
    return;
  }
  
  if (! this.categoryId && AI.categoryId) this.categoryId = AI.categoryId;
  const category = this.categoryId && AI.category(this.categoryId);
  
  let i;
  if (typeof message === "string") this.addMessage(message);
  else if (typeof message === "number") {
    for (i = message; i < this.messages.length; i++) this.removeMessage(message);
  }
  i = this.messages.length - 1;
  while (i > 0 && (this.messages[i].removed || this.messages[i].role === "assistant" || this.messages[i].role === "error")) {
    if (! this.messages[i].removed) this.removeMessage(i);
    i--;
  }
  
  this.completion = {};
  const assistantMessage = this.addMessage({role: "assistant", content: ""});
  assistantMessage.messageElement.classList.add("message-loading");
  AI.footerElement.classList.add("message-loading");
  const chat = this;
  
  let ticking = false;
  const onAnswer = function (chunks) {
    /*chat.completion = chunks.splice(0).reduce((completion, chunk) => {
      return {
        content: completion.content + (chunk.choices?.[0]?.delta?.content || ""),
        finish_reason: chunk.choices?.[0]?.finish_reason || completion.finish_reason,
      };
    }, chat.completion);*/
    for (let chunk of chunks.splice(0)) {
      if (! chat.completion.id) chat.completion.id = chunk.id;
      if (! chat.completion.object) chat.completion.object = chunk.object;
      if (! chat.completion.created) chat.completion.created = chunk.created;
      if (! chat.completion.model) chat.completion.model = chunk.model;
      if (! chat.completion.choices) chat.completion.choices = [];
      let choice = chat.completion.choices?.find(c => c.index === chunk.choices[0].index);
      if (choice) {
        if (! choice.message) choice.message = { ...chunk.choices[0]?.delta };
        else choice.message.content += chunk.choices[0]?.delta?.content || "";
      }
      else {
        choice = { ...chunk.choices[0] };
        if (choice && ! choice.message) {
          choice.message = { ...choice.delta };
          delete(choice.delta);
        }
        chat.completion.choices.push(choice);
      }
      if (chunk.choices[0].finish_reason) {
        chat.completion.choices[0].finish_reason = chunk.choices[0].finish_reason;
        chat.completion.object = "chat.completion";
      }
    }
    const message = chat.messages[assistantMessage.index];
    message.content = chat.completion.choices?.[0]?.message?.content || "";
    if (chat.completion.choices[0].finish_reason) {
      assistantMessage.messageElement.classList.remove("message-loading");
      AI.footerElement.classList.remove("message-loading");
    }
    //message.finish_reason = delta.finish_reason || message.finish_reason;
    if (chat.visible) {
      let content = message.content, imagePartial = content.match(IMAGE_PARTIAL_REGEX)?.[0];
      if (imagePartial) content = content.slice(0, -imagePartial.length) + "{{imagePartial}}";
      content = content.replaceAll(IMAGE_REGEX, (t, name, url) => {
        name = name.trim();
        const image = AI.imageLoader.images.find(image => image.searchQuery === name && image.items.length);
        return '<img class="imageLoader" src="' + (image? image.items[0].link: IMAGE_LOADER_DATAURI) + '" alt="' + name + '"' + (image? ` data-loader-id="${image.id}"`: '') + '>';
      });
      content = marked.parse(content);
      if (imagePartial) content = content.replace("{{imagePartial}}", imagePartial);
      content = content.replaceAll(EMOJI_REGEX, '<span class="emoji">$&</span>');
      morphdom(assistantMessage.contentElement, '<div class="message-content">' + content + '</div>');
      AI.imageLoader.init(assistantMessage.contentElement);
      AI.scrollingDown();
    }
  }

  const abortController = new AbortController();

  this.response = AI.chatCompletion({
    projectId: AI.config.projectId,
    categoryId: chat.categoryId,
    messages: this.messages.slice(0, -1).filter(message => ! message.removed && (typeof AI.config.chatMessageRoles[message.role].sendible === "undefined" || AI.config.chatMessageRoles[message.role].sendible)),
    onAnswer: chunks => {
      if (! ticking) {
        window.requestAnimationFrame(() => {
          onAnswer(chunks);
          ticking = false;
        });
        ticking = true;
      }
    },
    onError: error => {
      if (error.name !== 'AbortError') {
        chat.removeMessage(assistantMessage.index);
        chat.addMessage({role: "error", content: `Network error. <a href="#" onclick="AI.chat('${chat.id}').sendMessage(); return false;">Try again</a>.`});
        console.log(error);
      }
      assistantMessage.messageElement.classList.remove("message-loading");
      AI.footerElement.classList.remove("message-loading");
    },
    abortSignal: abortController.signal,
  });

  this.response.abort = () => {
    abortController.abort();
  }
  
  if (! this.title) {
    let firstMessage = this.messages.find(m => m.role === "user");
    if (firstMessage) {
      AI.completion(`Formulate a short description for this text and make it fewer than 40 characters:\n${ firstMessage.content }\n\n`, (answer) => {
        chat.title = answer.replace(/^\s*"\s*(.*)\s*"\s*$/, "$1").replace(/\.+$/, "");
        chat.chatListItemTitleElement.innerHTML = chat.title;
        AI.chatHeaderTitleElement.innerHTML = chat.title || "New project";
      });
    }
  }
}


AI.dialogue = {};

AI.dialogue.open = function (options) {
  if (! options) options = {};
  if (! this.element) {
    this.element = document.createElement("div");
    this.element.className = "dialogue dialogue-closed";
    this.element.innerHTML = '\
    <div class="dialogue-background">\
      <svg width="1920" height="1080" viewBox="0 0 1920 1080" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
        <g id="g1360">\
          <g opacity="0.04" id="g1283">\
            <path d="m 959.83203,18.117188 c -5.21775,0 -10.43544,1.347521 -15.14844,4.044921 l -93.58398,54.453125 c -9.257,5.3947 -14.98044,15.34106 -15.14844,26.130856 l -0.16797,108.23243 c 0,10.789 5.72244,20.90382 15.14844,26.29882 l 94.08789,54.45313 c 9.426,5.395 20.87088,5.395 30.29688,0 l 93.41409,-54.45313 c 9.26,-5.395 14.9804,-15.34086 15.1504,-26.13086 l 0.3398,-108.23242 c 0,-10.789197 -5.7304,-20.904126 -15.1504,-26.298826 L 974.98047,22.162109 c -4.713,-2.6974 -9.93069,-4.044921 -15.14844,-4.044921 z m -0.33789,14.582031 c 2.9035,0 5.80702,0.75809 8.41602,2.27539 l 27.9414,16.185547 c 5.08814,2.931766 5.50344,9.947797 1.27735,13.832032 l 2.93159,-1.695313 c 5.22,-3.0345 11.6101,-3.0345 16.8301,0 l 27.5996,16.015625 c 5.56,3.2031 5.56,11.296269 0,14.667969 l -75.90622,44.169921 c -5.218,3.034 -11.61307,3.034 -16.83007,0 l -40.41993,-23.34961 -0.14453,0.084 -36.01953,-20.904301 c -5.554,-3.3717 -5.554,-11.464769 0,-14.667969 l 75.9082,-44.337891 c 2.60902,-1.5173 5.51252,-2.27539 8.41602,-2.27539 z m 0.16797,24.402343 c -2.01975,0 -4.03913,0.548732 -5.89063,1.644532 l -36.01757,20.904297 15.3164,8.935547 34.50391,-19.892579 c 3.366,-1.8545 3.36603,-6.744578 -0.16797,-8.767578 l -1.85156,-1.179687 c -1.8515,-1.0958 -3.87283,-1.644532 -5.89258,-1.644532 z m 38.54687,22.253907 c -2.02062,0 -4.04107,0.548731 -5.89257,1.644531 l -36.01953,20.9043 15.3164,8.93554 34.33592,-19.894528 c 3.37,-1.854399 3.37,-6.742626 0,-8.765624 L 1004.0996,81 c -1.85,-1.0958 -3.87,-1.644531 -5.89062,-1.644531 z m 61.71092,32.460941 c 4.3341,0.024 8.3106,3.53164 8.3106,8.46289 v 15.50976 l -33.5,19.38867 v -4.72265 c 0,-3.877 -4.2103,-6.40581 -7.5703,-4.38281 l -16.5,9.77929 c -3.7,2.023 -5.8907,5.90124 -5.8907,10.11524 v 10.62109 c 0,3.878 4.2101,6.40581 7.5801,4.38281 l 43.0801,-25.11914 c 5.56,-3.372 12.6308,0.67305 12.6308,7.24805 l -0.3398,45.01367 c 0,5.9 -3.2002,11.46305 -8.4102,14.49805 l -75.91402,44.16797 c -5.555,3.372 -12.625,-0.67305 -12.625,-7.24805 v -15.50977 l 33.49802,-19.55664 v 4.72071 c 0,3.877 4.2003,6.40581 7.5703,4.38281 l 16.6602,-9.77734 c 3.71,-2.023 5.9004,-5.90024 5.9004,-10.11524 v -10.62109 c 0,-3.877 -4.2101,-6.40581 -7.5801,-4.38281 l -43.08788,25.28906 c -5.554,3.371 -12.62304,-0.675 -12.62304,-7.25 l 0.16796,-45.01367 c 0,-5.9 3.19802,-11.46405 8.41602,-14.49805 l 75.90624,-44.16992 c 1.39,-0.84275 2.8756,-1.22089 4.3203,-1.21289 z M 860.25,113.0918 c 1.44375,-0.0289 2.92595,0.31814 4.31445,1.11914 l 76.58399,44.33789 c 5.218,3.034 8.41601,8.59701 8.41601,14.66601 l -0.16797,59.51172 v 17.70117 10.6211 c 0,6.407 -7.06904,10.453 -12.62304,7.25 l -76.58399,-44.16992 c -5.217,-3.034 -8.41601,-8.59897 -8.41601,-14.66797 l 0.16797,-88 c 0,-4.80525 3.97734,-8.28257 8.30859,-8.36914 z m 29.98828,38.74414 c -2.60353,0.0634 -4.9707,2.11884 -4.9707,5.02734 l -0.16797,52.93555 c 0,4.215 2.18762,8.0922 5.89062,10.2832 l 17.50586,10.11524 c 3.366,1.855 7.57422,-0.50482 7.57422,-4.38282 l 0.16797,-52.93554 c 0,-4.214 -2.18762,-8.09221 -5.89062,-10.28321 L 892.8418,152.47852 c -0.8415,-0.4635 -1.73567,-0.66371 -2.60352,-0.64258 z" style="fill:#ffffff" />\
          </g>\
          <use xlink:href="#g1283" x="0" y="0" width="100%" height="100%" transform="translate(0,311.96731)" />\
        </g>\
        <use xlink:href="#g1360" x="0" y="0" width="100%" height="100%" transform="translate(274.38305,138.82981)" />\
        <use xlink:href="#g1360" x="0" y="0" width="100%" height="100%" transform="translate(548.76455,288.38931)" />\
        <use xlink:href="#g1360" x="0" y="0" width="100%" height="100%" transform="translate(823.15305,449.25181)" />\
        <use xlink:href="#g1360" x="0" y="0" width="100%" height="100%" transform="translate(-274.38645,138.82981)" />\
        <use xlink:href="#g1360" x="0" y="0" width="100%" height="100%" transform="translate(-548.77145,288.38931)" />\
        <use xlink:href="#g1360" x="0" y="0" width="100%" height="100%" transform="translate(-823.15565,449.25181)" />\
      </svg>\
    </div>\
    <div class="dialogue-container">\
      <div class="dialogue-top">\
        <a href="#close" class="dialogue-close">\
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">\
            <path d="M21,3 3,21" stroke-width="2" stroke-linecap="round"/>\
            <path d="M3,3 21,21" stroke-width="2" stroke-linecap="round"/>\
          </svg>\
        </a>\
      </div>\
      <div class="dialogue-content">\
        <form class="dialogue-form form" action="" method="post">\
          <div class="dialogue-header"></div>\
          <div class="dialogue-body"></div>\
          <div class="dialogue-buttons"></div>\
        </form>\
      </div>\
      <div class="dialogue-footer">\
        <p class="help">AI-Assistant by OBS Group</p>\
      </div>\
    </div>';
    document.body.appendChild(this.element);

    this.background = this.element.querySelector(".dialogue-background");
    this.containerElement = this.element.querySelector(".dialogue-container");
    this.contentElement = this.element.querySelector(".dialogue-content");
    this.headerElement = this.element.querySelector(".dialogue-header");
    this.bodyElement = this.element.querySelector(".dialogue-body");
    this.buttonsElement = this.element.querySelector(".dialogue-buttons");
    this.closeButton = this.element.querySelector(".dialogue-close");

    this.closeButton.addEventListener("click", (event) => {
      event.preventDefault();
      AI.dialogue.close();
    });

    this.background.addEventListener("click", () => {
      AI.dialogue.close();
    });
  }
  if (! this.opened) {
    this.opened = true;
    this.element.classList.remove("dialogue-closed");
  }
  if (typeof options.wide !== "undefined") {
    if (options.wide) this.element.classList.add("dialogue-wide");
    else this.element.classList.remove("dialogue-wide");
  }
  if (typeof options.scrolled !== "undefined") {
    if (options.scrolled) this.element.classList.add("dialogue-scrolled");
    else this.element.classList.remove("dialogue-scrolled");
  }
  if (typeof options.title !== "undefined") {
    this.headerElement.innerHTML = options.title;
  }
  if (typeof options.body !== "undefined") {
    this.bodyElement.innerHTML = options.body;
  }
  if (typeof options.buttons !== "undefined") {
    this.buttonsElement.innerHTML = options.buttons;
  }
}

AI.dialogue.content = function (content) {
  this.contentElement.innerHTML = content;
  this.headerElement = this.element.querySelector(".dialogue-header");
  this.bodyElement = this.element.querySelector(".dialogue-body");
  this.buttonsElement = this.element.querySelector(".dialogue-buttons");

  this.contentElement.querySelectorAll("textarea").forEach(e => {
    e.addEventListener("keyup", event => {
      if (e.scrollHeight > e.offsetHeight || e.scrollHeight + 4 < e.offsetHeight) {
        e.parentElement.style.height = (e.scrollHeight + 2) + 'px';
      }
    });
    e.addEventListener("blur", event => {
      e.parentElement.style.height = '1px';
      e.parentElement.style.height = (e.scrollHeight + 2) + 'px';
    });
    e.parentElement.style.height = (e.scrollHeight + 2) + 'px';
  });

  this.formElement = this.element.querySelector(".dialogue-form, .form");
  if (typeof this.onSubmit === "function") this.formElement.addEventListener("submit", this.onSubmit);
}

AI.dialogue.close = function () {
  if (this.opened) {
    this.opened = false;
    this.element.classList.add("dialogue-closed");
  }
}


AI.profile = {};

AI.profile.open = function () {
  AI.dialogue.open({
    title: "Profile Setings",
    body: "",
    buttons: "Loading...",
    wide: false,
    scrolled: false,
  });

  const headers = {
    'Content-Type': 'application/json',
    "Accept": "application/json",
  };
  fetch(AI.config.userAPIProfileEndpoint, {
    method: 'POST',
    headers: headers,
    body: JSON.stringify({
      action: "get",
      contentType: "html",
      projectId: AI.config.projectId,
    })
  }).then(response => {
    return response.json();
  }).then(data => {
    if (data.html) {
      AI.dialogue.open({
        wide: true,
        scrolled: true,
      });
      AI.dialogue.content(data.html);

      AI.profile.avatarUploadForm = AI.dialogue.element.querySelector("#avatarUploadForm");
      if (typeof AI.profile.onAvatarSubmit === "function") AI.profile.avatarUploadForm.addEventListener("submit", AI.profile.onAvatarSubmit);

      AI.profile.avatarUploadFile = AI.dialogue.element.querySelector("#avatarUploadForm_file");
      if (typeof AI.profile.onAvatarFileChange === "function") AI.profile.avatarUploadFile.addEventListener("change", AI.profile.onAvatarFileChange);
    }
    else if (data.error) {
      AI.dialogue.open({
        body: '<div class="messages"><div class="alert alert-danger"><div>' + data.error + '</div></div></div>',
        buttons: '<button type="button" class="button button-no-fill" onclick="AI.profile.close()">Close</button>',
      });
    }
  })
  .catch(error => {
  });

  AI.dialogue.onSubmit = AI.profile.onSubmit;
}

AI.profile.close = function () {
  AI.dialogue.close();
}

AI.profile.onSubmit = function (event) {
  event.preventDefault();
  const headers = {
    'Content-Type': 'application/json',
    "Accept": "application/json",
  };
  const formData = new FormData(AI.dialogue.formElement);
  const data = {
    action: "update",
    contentType: "html",
    projectId: AI.config.projectId,
  };
  for (let [key, value] of formData) {
    let keys = key.replace(/^\[/, "").replace(/\]$/, "").split(/\]?\[/) || null, d = data;
    keys.forEach((k, i) => {
      if (i >= keys.length - 1) {
        if (typeof d[k] !== "undefined") {
          if (! Array.isArray(d[k])) d[k] = [d[k]];
          d[k].push(value);
        }
        else d[k] = value;
      }
      else {
        if (typeof d[k] === "undefined") d[k] = {};
        d = d[k];
      }
    });
  }
  fetch(AI.dialogue.formElement.action || AI.config.userAPIProfileEndpoint, {
    method: 'POST',
    headers: headers,
    body: JSON.stringify(data),
  })
  .then(response => {
    return response.json();
  })
  .then(data => {
    if (data.html) {
      AI.dialogue.content(data.html);
      if (data.user) {
        document.querySelector("#chatUserAvatar_image").setAttribute('href', data.user.avatarUrl);
        document.querySelector("#userMenuName .item").innerHTML = `<h3>${data.user.fullName}</h3>${data.user.username}`;
        document.querySelector("#detailsOPMCohort val").innerHTML = data.user.OPMCohort;
        document.querySelector("#detailsLocation val").innerHTML = data.user.location;
      }
    }
  })
  .catch(error => {
  });
};

AI.profile.onAvatarSubmit = function (event) {
  event.preventDefault();
  let data = new FormData(), file = document.querySelector('#avatarUploadForm [name=avatarFile]').files[0];
  data.append('avatarFile', file, window.encodeURIComponent(file.name));

  const headers = {
    //'Content-Type': 'application/json',
    "Accept": "application/json",
  };
  fetch('/api/user/avatar/upload', {
    method: 'POST',
    headers: headers,
    body: data,
  })
  .then(response => {
    return response.json();
  })
  .then(data => {
    console.log(data)
    if (data.success) {
      let e = document.querySelector('[id="user[avatarId]"]');
      if (e) e.value = data.id;
      e.parentNode.querySelector('.userAvatar img').src = data.url;
    }
  })
  .catch(error => {
  });
  //return false;
};

AI.profile.onAvatarFileChange = function (event) {
  if (AI.profile.avatarUploadForm ) AI.profile.avatarUploadForm.dispatchEvent(new Event('submit'));
};



AI.scrollingElement = document.scrollingElement || document.body;
AI.chatElement = document.querySelector(AI.config.chatContainer);
AI.footerElement = document.querySelector(AI.config.footerContainer);

AI.scrollingDown = function (scrollDown) {
  if (arguments.length? scrollDown: AI.scrollDown) AI.scrollingElement.scrollTop = AI.scrollingElement.scrollHeight;
  return AI.scrollingElement.scrollHeight - AI.scrollingElement.offsetHeight - AI.scrollingElement.scrollTop < 100;
}



window.addEventListener('resize', function (event) {  
  AI.chatElement.style.paddingBottom = AI.footerElement.clientHeight + "px";
}, true);

document.getElementById("chatHeaderAvatar").addEventListener("click", (event) => {
  let e = document.getElementById("chatHeaderUserMenu");
  e.classList.toggle('show');
});
document.addEventListener("click", (event) => {
  let e = document.getElementById("chatHeaderUserMenu");
  if (! e.contains(event.target)) e.classList.remove('show');
});


})();
