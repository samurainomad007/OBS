const express = require('express');
const fs = require('fs');
const path = require('path');
const favicon = require('static-favicon');
const logger = require('morgan');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const passport=require('passport');
const LocalStrategy=require('passport-local').Strategy;
const session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);
require('dotenv').config();
const mysql = require('mysql2');
const crypto = require('node:crypto');
const multer = require("multer");
const sharp = require('sharp');

const config = require('./config/app');

const db = mysql.createPool({
  connectionLimit : 100,
  host: config.mysql.host,
  port: config.mysql.port,
  user: config.mysql.user,
  password: config.mysql.password,
  database: config.mysql.database,
  //multipleStatements: true
}).promise();
/*db.connect((err) => {
  if (!err) {
  }
  else {
    console.log("DB Conection Failed");
  }
});*
db.queryPromise = async function (query, queryData) {
  return new Promise((resolve, reject) => {
    //https://stackoverflow.com/questions/54730648/nodejs-mysql-multiple-update
    this.query(query, queryData, function (error, result) {
      if (error) {
        reject(error);
        return;
      }
      resolve(result);
    });
  });
};/






/*function DiskStorage (opts) {
  this.getId = (opts.id || function (req, file, callback) {
    callback(null, null);
  });

  this.getFilename = (opts.filename || function (req, file, callback) {
    crypto.randomBytes(16, function (err, raw) {
      callback(err, err ? undefined : raw.toString('hex') + path.extname(file.originalname));
    });
  });

  if (typeof opts.destination === 'string') {
    mkdirp.sync(opts.destination);
    this.getDestination = function ($0, $1, callback) { callback(null, opts.destination); }
  }
  else {
    this.getDestination = (opts.destination || function (req, file, callback) {
      callback(null, os.tmpdir());
    });
  }
}

DiskStorage.prototype._handleFile = function _handleFile (req, file, callback) {
  var that = this;

  that.getDestination(req, file, function (err, destination) {
    if (err) return callback(err);

    that.getFilename(req, file, function (err, filename) {
      if (err) return callback(err);
      var finalPath = path.join(destination, filename);
      var outStream = fs.createWriteStream(finalPath);

      file.stream.pipe(outStream);
      outStream.on('error', callback);
      outStream.on('finish', function () {
        file.filename =  filename;
        that.getId(req, file, function (err, id) {
          if (err) return callback(err);
          callback(null, {
            id: id,
            originalname: file.originalname,
            destination: destination,
            filename: filename,
            path: finalPath,
            size: outStream.bytesWritten
          });
        });
      });
    });
  });
}

DiskStorage.prototype._removeFile = function _removeFile (req, file, callback) {
  var path = file.path;

  delete file.destination;
  delete file.filename;
  delete file.path;

  fs.unlink(path, callback);
}*/

const images = {
  avatarMaxSize: 10 * 1000 * 1000,
  sizes: {
    original: {
      dirname: __dirname + "/public/images/original",
      baseUrl: config.baseUrl + "images/original/",
    },
    thumbnail: {
      width: 256,
      height: 256,
      fit: sharp.fit.cover,
      position: sharp.strategy.attention,
      dirname: __dirname + "/public/images/thumbnail",
      baseUrl: config.baseUrl + "images/thumbnail/",
    }
  },
};

images.storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, __dirname + "/public/images/original");
  },
  filename: function (req, file, callback) {
    crypto.randomBytes(16, function (err, raw) {
      callback(err, err ? undefined : raw.toString('hex') + path.extname(file.originalname));
    })
  }
});

/*images.storage = new DiskStorage({
  destination: function (req, file, callback) {
    callback(null, __dirname + "/public/images/original");
  },
  id: async function (req, file, callback) {
    const metadata = await sharp(__dirname + "/public/images/original/" + file.filename).metadata();
    db.query("INSERT INTO images (filename, filename_original, size, mime_type, width, height, type, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", 
      [file.filename, file.originalname, metadata.size, file.mimetype, metadata.width, metadata.height, "original", req.user.id], 
      function(err) {
        if (err) return callback(err);
        callback(null, this.lastID);
      }
    );
  },
});*/

images.avatarUpload = multer({ 
  storage: images.storage,
  limits: { fileSize: images.avatarMaxSize },
  fileFilter: function (req, file, callback){
    var filetypes = /jpeg|jpg|png/;
    var mimetype = filetypes.test(file.mimetype);
    var extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    
    if (mimetype && extname) {
      return callback(null, true);
    }
  
    callback("The image must be in JPEG or PNG format.");
  }
}).single("avatarFile");

images.save = async function (image) {
  if (! image.type) image.type = "original";
  if (image.filename) {
    const metadata = await sharp(images.sizes[image.type].dirname + "/" + image.filename).metadata();
    image.width = metadata.width;
    image.height = metadata.height;
  }
  let paramNames = [], params = [], isUpdate = false;
  for (let param in image) {
    if (["id", "filename", "filename_original", "size", "mime_type", "width", "height", "type", "parent_id", "user_id", "created_at", "deleted"].includes(param)) {
      if (param === "id") isUpdate = true;
      paramNames.push(param);
      params.push(image[param]);
    }
  }
  if (isUpdate) {
    const [result] = await db.query("UPDATE `images` SET `" + paramNames.join("`=?, `") + "`=? WHERE `id`=?",  params);
    if (result) return true;
  }
  else {
    const [result] = await db.query("INSERT INTO `images` (`" + paramNames.join("`, `") + "`) VALUES (" + paramNames.map(() => "?").join(", ") + ")",  params);
    //filename, filename_original, size, mime_type, width, height, type, user_id  
    //[image.filename, image.filename_original, image.size, image.mime_type || ("image/" + metadata.format), metadata.width, metadata.height, image.type, image.user_id]
    if (result) return result.insertId;
  }
};

images.get = async function (image) {
  return new Promise(async (resolve, reject) => {
    try {
      if (typeof image !== "object") image = { id: image };
      let [rows] = await db.query("SELECT * FROM images WHERE id=? LIMIT 1", [image.id]);
      if (rows && rows.length) {
        image = {
          ...rows[0],
          url: images.sizes[rows[0].type].baseUrl + rows[0].filename,
        };
      }
      else {
        resolve();
        return;
      }
      resolve(image);
    }
    catch (error) {
      reject(error);
    }
  });
};

images.getResized = async function (image, type) {
  return new Promise(async (resolve, reject) => {
    try {
      let filename, rows;
      if (typeof image !== "object") image = { id: image };
      if (! image.id) {
        resolve();
        return;
      }
      if (! image.type || ! image.filename || ! image.user_id) {
        [rows] = await db.query("SELECT * FROM images WHERE id=? LIMIT 1", [image.id]);
        if (rows && rows.length) image = { ...rows[0] };
        else {
          resolve();
          return;
        }
      }
      [rows] = await db.query("SELECT * FROM images WHERE parent_id=? AND type=? LIMIT 1", [image.id, type]);
      if (rows && rows.length) {
        resolve({
          ...rows[0],
          url: images.sizes[type].baseUrl + rows[0].filename,
        });
        return;
      }
      crypto.randomBytes(16, function (err, raw) {
        filename = err ? undefined : raw.toString('hex') + ".jpeg";
      });
      const resized = await sharp(images.sizes[image.type].dirname + "/" + image.filename)
        .resize({ width: images.sizes[type].width, height: images.sizes[type].height, fit: images.sizes[type].fit, position: images.sizes[type].position, })
        .toFormat("jpeg", { mozjpeg: true })
        .toBuffer({ resolveWithObject: true });
      fs.writeFileSync(images.sizes[type].dirname + "/" + filename, resized.data, { flag: 'w' });
      let [result] = await db.query(
        "INSERT INTO images (filename, filename_original, size, mime_type, width, height, type, parent_id, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", 
        [filename, image.filename_original || "", resized.info.size, "image/jpeg", resized.info.width, resized.info.height, type, image.id, image.user_id]
      );
      if (result) {
        [rows] = await db.query("SELECT * FROM images WHERE id=? LIMIT 1", [result.insertId]);
        if (rows && rows.length) {
          resolve({
            ...rows[0],
            url: images.sizes[type].baseUrl + rows[0].filename,
          });
          return;
        }
        else {
          resolve();
          return;
        }
      }
    }
    catch (error) {
      reject(error);
    }
  });
};


var indexRouter = require('./routes/index');
var adminRouter = require('./routes/admin/index');
var apiRouter = require('./routes/api');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(favicon());
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
	key: 'OSID',
	secret: 'qwe----------qwexx1092',
	store: new MySQLStore({}, db),
	resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000*60*60*24,
  }
}));

const auth = {
  validatePassword: function (password, hash, salt) {
    var hashVerify = crypto.pbkdf2Sync(password, salt, 10000, 60, 'sha512').toString('hex');
    return hash === hashVerify;
  },
  
  hashPassword: function (password) {
    var salt = crypto.randomBytes(32).toString('hex');
    var hash = crypto.pbkdf2Sync(password, salt, 10000, 60, 'sha512').toString('hex');
    return { salt: salt, hash: hash };
  },
  
  isEnabled: function (req, res, next) {
    if (req.isAuthenticated() && req.user.enabled) {
      next();
    }
    else {
      if (req.query.guestUrl) res.redirect(req.query.guestUrl);
      else if (! req.query.url && req.originalUrl === "/opm-social") res.redirect("/opm-social/home");
      else res.redirect('/login?url=' + encodeURI(req.query.url || req.originalUrl));
    }
  },
  
  isAdmin: function (req, res, next) {
    if (req.isAuthenticated() && req.user.enabled && req.user.role === "admin") {
      next();
    }
    else {
      res.redirect('/login?url=' + encodeURI(req.query.url || req.originalUrl));
    }   
  },
};

passport.use(
  new LocalStrategy(
    {
      usernameField: 'username',
      passwordField: 'password',
    },
    function verify(username, password, done) {
      db.query('SELECT * FROM users WHERE username = ? ', [username])
      .then( ([rows, fields]) => {
        if (rows.length === 0) {
          return done(null, false);
        }
        if (auth.validatePassword(password, rows[0].hash, rows[0].salt)) {
          return done(null, {
            id: rows[0].id,
            username: rows[0].username,
            hash: rows[0].hash,
            salt: rows[0].salt,
            enabled: rows[0].enabled,
            data: rows[0].data && JSON.parse(rows[0].data)
          });
        }
        else {
          return done(null, false);
        }
      })
      .catch(error => {
        return done(error);
      });
    }
  )
);

passport.serializeUser((user, done) => {
  //done(null, user.id);
  process.nextTick(function () {
    return done(null, { id: user.id, username: user.username, enabled: user.enabled, data: user.data });
  });
});

passport.deserializeUser((user, done) => {
  /*process.nextTick(function () {
    db.query('SELECT * FROM users WHERE id = ?',[user.id], function (error, results) {
      if (error) return done(error);
      return done(null, {
        id: results[0].id,
        username: results[0].username,
        hash: results[0].hash,
        salt: results[0].salt,
        enabled: results[0].enabled,
        data: results[0].data && JSON.parse(results[0].data)
      });    
    });
  });*/
  process.nextTick(function () {
    return done(null, user);
  });
});

app.use(passport.initialize());
app.use(passport.session());


app.use(function (req, res, next) {
  res.header('Access-Control-Allow-Credentials', true);
  res.header('Access-Control-Allow-Origin', req.headers.origin);
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
  res.header('Access-Control-Allow-Headers', 'X-Requested-With, X-HTTP-Method-Override, Content-Type, Accept');

  res.locals.messages = req.session?.messages?.slice(0) || [];
  req.session.messages = [];

  res.locals.config = config;
  res.locals.db = db;
  res.locals.images = images;
  res.locals.passport = passport;
  res.locals.auth = auth;
  next();
});



app.use('/', indexRouter);
app.use('/admin', adminRouter);
app.use('/api', apiRouter);

/// catch 404 and forwarding to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

//  error handler
app.use(function(err, req, res, next) {
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development'? err : {};

    if (req.xhr || (req.headers.accept && req.headers.accept.indexOf('json') >= 0)) {
      res.status(200).json({ result: 'error', messages: [{ message: res.locals.message || "Unspecified error. Try refreshing the page.", type: "error" }] });
    }
    else {
      res.status(err.status || 500);
      res.render('error', {
        message: res.locals.message,
        error: res.locals.error
      });
    }
});


module.exports = app;
